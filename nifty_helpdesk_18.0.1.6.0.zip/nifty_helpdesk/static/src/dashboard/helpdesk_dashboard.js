/** @odoo-module **/

import { Component, onMounted, onPatched, onWillStart, onWillUnmount, useRef, useState } from "@odoo/owl";
import { loadBundle } from "@web/core/assets";
import { _t } from "@web/core/l10n/translation";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

const SERIES = ["--hd-series-1", "--hd-series-2", "--hd-series-3"];

function isoDate(date) {
    const pad = (n) => String(n).padStart(2, "0");
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

/** Splits a long axis label into lines of about `width` characters. */
function wrapLabel(text, width = 14) {
    const lines = [];
    let line = "";
    for (const word of String(text).split(/\s+/)) {
        if (line && (line + " " + word).length > width) {
            lines.push(line);
            line = word;
        } else {
            line = line ? `${line} ${word}` : word;
        }
    }
    if (line) {
        lines.push(line);
    }
    return lines.length > 2 ? [lines[0], `${lines.slice(1).join(" ").slice(0, width - 1)}…`] : lines;
}

function presetRange(preset) {
    const today = new Date();
    const y = today.getFullYear();
    const m = today.getMonth();
    switch (preset) {
        case "this_month":
            return [new Date(y, m, 1), today];
        case "last_30":
            return [new Date(y, m, today.getDate() - 29), today];
        case "this_quarter":
            return [new Date(y, Math.floor(m / 3) * 3, 1), today];
        case "this_year":
            return [new Date(y, 0, 1), today];
        case "last_year":
            return [new Date(y - 1, 0, 1), new Date(y - 1, 11, 31)];
        default:
            return null;
    }
}

/** Draws each bar's value just outside its end, in text ink, for a few bars. */
const valueLabels = {
    id: "hdValueLabels",
    afterDatasetsDraw(chart, _args, options) {
        if (!options || !options.enabled) {
            return;
        }
        const { ctx } = chart;
        const horizontal = chart.options.indexAxis === "y";
        const stacked = Boolean(chart.options.scales?.x?.stacked);
        ctx.save();
        ctx.font = "600 12px system-ui, sans-serif";
        ctx.fillStyle = options.color;
        const lastIndex = chart.data.datasets.length - 1;
        chart.data.datasets.forEach((dataset, datasetIndex) => {
            if (stacked && datasetIndex !== lastIndex) {
                return;
            }
            const meta = chart.getDatasetMeta(datasetIndex);
            if (meta.hidden) {
                return;
            }
            meta.data.forEach((bar, index) => {
                const value = stacked ? options.totals[index] : dataset.data[index];
                if (!value) {
                    return;
                }
                const text = options.format ? options.format(value) : String(value);
                if (horizontal) {
                    ctx.textAlign = "left";
                    ctx.textBaseline = "middle";
                    ctx.fillText(text, bar.x + 6, bar.y);
                } else {
                    ctx.textAlign = "center";
                    ctx.textBaseline = "bottom";
                    ctx.fillText(text, bar.x, bar.y - 6);
                }
            });
        });
        ctx.restore();
    },
};

/** Writes the total in the hole of a doughnut. */
const doughnutCenter = {
    id: "hdDoughnutCenter",
    afterDraw(chart, _args, options) {
        if (!options || !options.text) {
            return;
        }
        const { ctx, chartArea } = chart;
        const x = (chartArea.left + chartArea.right) / 2;
        const y = (chartArea.top + chartArea.bottom) / 2;
        ctx.save();
        ctx.textAlign = "center";
        ctx.fillStyle = options.color;
        ctx.font = "600 24px system-ui, sans-serif";
        ctx.textBaseline = "bottom";
        ctx.fillText(options.text, x, y + 4);
        ctx.fillStyle = options.subColor;
        ctx.font = "12px system-ui, sans-serif";
        ctx.textBaseline = "top";
        ctx.fillText(options.subText, x, y + 8);
        ctx.restore();
    },
};

export class HelpdeskDashboard extends Component {
    static template = "nifty_helpdesk.HelpdeskDashboard";
    static props = ["*"];

    setup() {
        this.orm = useService("orm");
        this.action = useService("action");
        this.root = useRef("root");
        this.charts = {};
        // Charts are drawn after OWL has patched the DOM, so canvases exist.
        this.chartsStale = true;
        const [start, end] = presetRange("this_year");
        this.state = useState({
            loading: true,
            data: null,
            preset: "this_year",
            filters: {
                date_from: isoDate(start),
                date_to: isoDate(end),
                team_id: "",
                user_id: "",
                job_type_id: "",
                priority: "",
            },
            tables: {},
        });
        this.presets = [
            ["this_month", _t("This month")],
            ["last_30", _t("Last 30 days")],
            ["this_quarter", _t("This quarter")],
            ["this_year", _t("This year")],
            ["last_year", _t("Last year")],
            ["custom", _t("Custom")],
        ];

        onWillStart(async () => {
            await loadBundle("web.chartjs_lib");
            await this.load();
        });
        const drawIfStale = () => {
            if (this.chartsStale) {
                this.chartsStale = false;
                this.renderCharts();
            }
        };
        onMounted(drawIfStale);
        onPatched(drawIfStale);
        onWillUnmount(() => this.destroyCharts());
    }

    // ------------------------------------------------------------
    // Data
    // ------------------------------------------------------------

    async load() {
        this.state.loading = true;
        const data = await this.orm.call("helpdesk.ticket", "get_dashboard_data", [], {
            filters: { ...this.state.filters },
        });
        this.chartsStale = true;
        this.state.data = data;
        this.state.loading = false;
    }

    async reload() {
        await this.load();
    }

    get kpis() {
        return this.state.data.kpis;
    }

    get isEmpty() {
        return !this.kpis.total;
    }

    formatHours(value) {
        if (!value) {
            return "0 h";
        }
        return value >= 10 ? `${Math.round(value)} h` : `${value.toFixed(1)} h`;
    }

    formatNumber(value) {
        return (value || 0).toLocaleString();
    }

    // ------------------------------------------------------------
    // Filters
    // ------------------------------------------------------------

    onPreset(ev) {
        const preset = ev.target.value;
        this.state.preset = preset;
        const range = presetRange(preset);
        if (range) {
            this.state.filters.date_from = isoDate(range[0]);
            this.state.filters.date_to = isoDate(range[1]);
            this.reload();
        }
    }

    onDate(field, ev) {
        this.state.filters[field] = ev.target.value;
        this.state.preset = "custom";
        if (this.state.filters.date_from && this.state.filters.date_to) {
            this.reload();
        }
    }

    onFilter(field, ev) {
        this.state.filters[field] = ev.target.value;
        this.reload();
    }

    onReset() {
        const [start, end] = presetRange("this_year");
        Object.assign(this.state.filters, {
            date_from: isoDate(start),
            date_to: isoDate(end),
            team_id: "",
            user_id: "",
            job_type_id: "",
            priority: "",
        });
        this.state.preset = "this_year";
        this.reload();
    }

    get hasActiveFilters() {
        const f = this.state.filters;
        return Boolean(f.team_id || f.user_id || f.job_type_id || f.priority || this.state.preset !== "this_year");
    }

    toggleTable(key) {
        // Switching back from a table re-creates that card's canvas.
        this.chartsStale = true;
        this.state.tables[key] = !this.state.tables[key];
    }

    // ------------------------------------------------------------
    // Drill-down
    // ------------------------------------------------------------

    openTickets(extraDomain = [], title = _t("Tickets")) {
        this.action.doAction({
            type: "ir.actions.act_window",
            name: title,
            res_model: "helpdesk.ticket",
            views: [
                [false, "list"],
                [false, "kanban"],
                [false, "form"],
            ],
            domain: [...this.state.data.domain, ...extraDomain],
            context: { active_test: true },
        });
    }

    openStatus(key, label) {
        this.openTickets(this.state.data.status_domains[key], label);
    }

    // ------------------------------------------------------------
    // Charts
    // ------------------------------------------------------------

    cssVar(name) {
        return getComputedStyle(this.root.el).getPropertyValue(name).trim();
    }

    destroyCharts() {
        Object.values(this.charts).forEach((chart) => chart.destroy());
        this.charts = {};
    }

    baseOptions() {
        const text = this.cssVar("--hd-text-secondary");
        const grid = this.cssVar("--hd-grid");
        return {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 250 },
            plugins: {
                legend: {
                    labels: { color: text, usePointStyle: true, pointStyle: "rectRounded", boxWidth: 10, boxHeight: 10 },
                },
                tooltip: {
                    backgroundColor: this.cssVar("--hd-tooltip-bg"),
                    titleColor: this.cssVar("--hd-tooltip-text"),
                    bodyColor: this.cssVar("--hd-tooltip-text"),
                    padding: 10,
                    cornerRadius: 6,
                    boxPadding: 4,
                    usePointStyle: true,
                },
            },
            scales: {
                x: {
                    grid: { display: false },
                    border: { color: grid },
                    ticks: { color: text, maxRotation: 0, autoSkip: true },
                },
                y: {
                    beginAtZero: true,
                    grid: { color: grid },
                    border: { display: false },
                    ticks: { color: text, precision: 0 },
                },
            },
        };
    }

    renderCharts() {
        if (!this.state.data || this.isEmpty) {
            this.destroyCharts();
            return;
        }
        this.destroyCharts();
        const data = this.state.data;
        const colors = SERIES.map((name) => this.cssVar(name));
        const surface = this.cssVar("--hd-surface");
        const ink = this.cssVar("--hd-text-primary");
        const muted = this.cssVar("--hd-text-secondary");
        const make = (key, config) => {
            const canvas = this.root.el.querySelector(`canvas[data-chart="${key}"]`);
            if (canvas) {
                this.charts[key] = new Chart(canvas, config);
            }
        };
        const clickable = (handler) => ({
            onClick: (_event, elements) => elements.length && handler(elements[0]),
            onHover: (event, elements) => {
                event.native.target.style.cursor = elements.length ? "pointer" : "default";
            },
        });

        // 1. Average working hours to resolve, per job type
        const withHours = data.by_job_type.filter((row) => row.avg_close_hours > 0);
        withHours.sort((a, b) => b.avg_close_hours - a.avg_close_hours);
        make("jobHours", {
            type: "bar",
            data: {
                labels: withHours.map((row) => wrapLabel(row.name)),
                datasets: [{
                    label: _t("Avg. working hours to resolve"),
                    data: withHours.map((row) => row.avg_close_hours),
                    backgroundColor: colors[0],
                    borderRadius: { topLeft: 4, topRight: 4 },
                    borderSkipped: "bottom",
                    maxBarThickness: 36,
                }],
            },
            options: {
                ...this.baseOptions(),
                ...clickable((el) => this.openTickets(withHours[el.index].domain, withHours[el.index].name)),
                layout: { padding: { top: 22 } },
                plugins: {
                    ...this.baseOptions().plugins,
                    legend: { display: false },
                    hdValueLabels: { enabled: true, color: ink, format: (v) => this.formatHours(v) },
                    tooltip: {
                        ...this.baseOptions().plugins.tooltip,
                        callbacks: { label: (ctx) => ` ${this.formatHours(ctx.parsed.y)}` },
                    },
                },
            },
            plugins: [valueLabels],
        });

        // 2. Resolved and unresolved tickets by month of creation
        make("months", {
            type: "line",
            data: {
                labels: data.by_month.map((row) => row.label),
                datasets: [
                    { key: "resolved", label: _t("Resolved"), color: colors[0] },
                    { key: "unresolved", label: _t("Unresolved"), color: colors[1] },
                ].map((series) => ({
                    label: series.label,
                    data: data.by_month.map((row) => row[series.key]),
                    borderColor: series.color,
                    backgroundColor: series.color,
                    borderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 6,
                    pointBorderColor: surface,
                    pointBorderWidth: 2,
                    tension: 0.25,
                })),
            },
            options: {
                ...this.baseOptions(),
                interaction: { mode: "index", intersect: false },
                ...clickable((el) => {
                    const month = data.by_month[el.index];
                    this.openTickets(month.domain, month.label);
                }),
            },
        });

        // 3. Support status
        const status = data.status;
        make("status", {
            type: "doughnut",
            data: {
                labels: status.map((row) => `${row.label} · ${this.formatNumber(row.count)}`),
                datasets: [{
                    data: status.map((row) => row.count),
                    backgroundColor: colors,
                    borderColor: surface,
                    borderWidth: 2,
                    hoverOffset: 4,
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: "64%",
                ...clickable((el) => this.openStatus(status[el.index].key, status[el.index].label)),
                plugins: {
                    legend: { position: "right", labels: this.baseOptions().plugins.legend.labels },
                    tooltip: {
                        ...this.baseOptions().plugins.tooltip,
                        callbacks: {
                            label: (ctx) => {
                                const total = this.kpis.total || 1;
                                const value = ctx.parsed;
                                return ` ${this.formatNumber(value)} (${Math.round((100 * value) / total)}%)`;
                            },
                        },
                    },
                    hdDoughnutCenter: {
                        text: this.formatNumber(this.kpis.total),
                        subText: _t("tickets"),
                        color: ink,
                        subColor: muted,
                    },
                },
            },
            plugins: [doughnutCenter],
        });

        // 4. Tickets per job type, stacked by status
        const statusKeys = [
            ["resolved", _t("Resolved")],
            ["in_progress", _t("In progress")],
            ["unassigned", _t("Unassigned")],
        ];
        const jobs = data.by_job_type;
        const totals = jobs.map((row) => row.resolved + row.in_progress + row.unassigned);
        const baseStacked = this.baseOptions();
        make("jobStatus", {
            type: "bar",
            data: {
                labels: jobs.map((row) => wrapLabel(row.name)),
                datasets: statusKeys.map(([key, label], index) => ({
                    label,
                    data: jobs.map((row) => row[key]),
                    backgroundColor: colors[index],
                    borderColor: surface,
                    borderWidth: { top: 2 },
                    borderSkipped: false,
                    borderRadius: index === statusKeys.length - 1 ? { topLeft: 4, topRight: 4 } : 0,
                    maxBarThickness: 36,
                })),
            },
            options: {
                ...baseStacked,
                layout: { padding: { top: 22 } },
                scales: {
                    x: { ...baseStacked.scales.x, stacked: true },
                    y: { ...baseStacked.scales.y, stacked: true },
                },
                ...clickable((el) => {
                    const row = jobs[el.index];
                    const [key, label] = statusKeys[el.datasetIndex];
                    this.openTickets([...row.domain, ...data.status_domains[key]], `${row.name} · ${label}`);
                }),
                plugins: {
                    ...baseStacked.plugins,
                    hdValueLabels: { enabled: true, color: ink, totals },
                    tooltip: { ...baseStacked.plugins.tooltip, mode: "index", intersect: false },
                },
            },
            plugins: [valueLabels],
        });

        // 5. Resolved tickets per engineer
        const engineers = data.by_engineer;
        const baseHorizontal = this.baseOptions();
        make("engineers", {
            type: "bar",
            data: {
                labels: engineers.map((row) => row.name),
                datasets: [{
                    label: _t("Resolved tickets"),
                    data: engineers.map((row) => row.count),
                    backgroundColor: colors[0],
                    borderRadius: { topRight: 4, bottomRight: 4 },
                    borderSkipped: "left",
                    maxBarThickness: 22,
                }],
            },
            options: {
                ...baseHorizontal,
                indexAxis: "y",
                layout: { padding: { right: 36 } },
                scales: {
                    x: { ...baseHorizontal.scales.y },
                    y: { ...baseHorizontal.scales.x },
                },
                ...clickable((el) => {
                    const row = engineers[el.index];
                    this.openTickets([...row.domain, ...data.status_domains.resolved], row.name);
                }),
                plugins: {
                    ...baseHorizontal.plugins,
                    legend: { display: false },
                    hdValueLabels: { enabled: true, color: ink },
                },
            },
            plugins: [valueLabels],
        });
    }
}

registry.category("actions").add("nifty_helpdesk_dashboard", HelpdeskDashboard);
