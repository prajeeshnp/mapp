/** @odoo-module **/

import { Component } from "@odoo/owl";
import { _t } from "@web/core/l10n/translation";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { standardFieldProps } from "@web/views/fields/standard_field_props";

const RADIUS = 42;
const STROKE = 14;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;
// A thin surface-coloured gap between donut segments.
const GAP = 2;

/**
 * Small SVG charts for a team card on the Helpdesk Overview: a status donut,
 * an open-tickets-by-priority bar and a 7-day created/resolved trend.
 * Each mark opens the matching tickets.
 */
export class TeamOverviewCharts extends Component {
    static template = "nifty_helpdesk.TeamOverviewCharts";
    static props = { ...standardFieldProps };

    setup() {
        this.action = useService("action");
        this.orm = useService("orm");
        this.RADIUS = RADIUS;
        this.STROKE = STROKE;
    }

    get stats() {
        return this.props.record.data[this.props.name] || { status: [], priority: [], trend: [] };
    }

    // ------------------------------------------------------------
    // Donut
    // ------------------------------------------------------------

    get statusTotal() {
        return this.stats.status.reduce((sum, row) => sum + row.count, 0);
    }

    get donutSegments() {
        const total = this.statusTotal;
        if (!total) {
            return [];
        }
        let offset = 0;
        const visible = this.stats.status.filter((row) => row.count);
        return this.stats.status.map((row, index) => {
            const share = row.count / total;
            const length = share * CIRCUMFERENCE;
            const gap = visible.length > 1 && row.count ? GAP : 0;
            const segment = {
                ...row,
                index,
                percent: Math.round(share * 100),
                dash: `${Math.max(length - gap, 0)} ${CIRCUMFERENCE}`,
                offset: -offset,
            };
            offset += length;
            return segment;
        });
    }

    // ------------------------------------------------------------
    // Priority bar
    // ------------------------------------------------------------

    get priorityTotal() {
        return this.stats.priority.reduce((sum, row) => sum + row.count, 0);
    }

    get prioritySegments() {
        const total = this.priorityTotal;
        return this.stats.priority.map((row, index) => ({
            ...row,
            index,
            width: total ? (100 * row.count) / total : 0,
        }));
    }

    // ------------------------------------------------------------
    // 7-day trend
    // ------------------------------------------------------------

    get trendMax() {
        return Math.max(1, ...this.stats.trend.map((day) => Math.max(day.created, day.resolved)));
    }

    barHeight(value) {
        // Leave a 2px stub for zero so the day still reads as "measured".
        return value ? Math.max(4, Math.round((value / this.trendMax) * 56)) : 2;
    }

    get trendTotals() {
        return this.stats.trend.reduce(
            (totals, day) => ({ created: totals.created + day.created, resolved: totals.resolved + day.resolved }),
            { created: 0, resolved: 0 }
        );
    }

    // ------------------------------------------------------------
    // Drill-down
    // ------------------------------------------------------------

    async open(kind, key, count) {
        if (!count) {
            return;
        }
        const action = await this.orm.call("helpdesk.team", "action_view_overview_segment", [
            [this.props.record.resId],
            kind,
            key,
        ]);
        this.action.doAction(action);
    }

    tooltip(label, count, extra = "") {
        return `${label}: ${count}${extra}`;
    }

    get labels() {
        return {
            status: _t("Last %s days", this.stats.status_days || 30),
            priority: _t("Open by priority"),
            trend: _t("Last 7 days"),
            created: _t("New"),
            resolved: _t("Resolved"),
            tickets: _t("tickets"),
        };
    }
}

export const teamOverviewCharts = {
    component: TeamOverviewCharts,
    displayName: _t("Helpdesk team charts"),
    supportedTypes: ["json"],
};

registry.category("fields").add("hd_team_overview_charts", teamOverviewCharts);
