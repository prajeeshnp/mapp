import re

from odoo.tests import TransactionCase, tagged

from .common import setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestTicket(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)

    def _create_ticket(self, **values):
        return self.env['helpdesk.ticket'].create({'name': 'Printer down', 'team_id': self.team.id, **values})

    def test_sequence_is_formatted_and_increments(self):
        first = self._create_ticket()
        second = self._create_ticket()
        self.assertRegex(first.ref, r'^HD/\d{5}$')
        first_number = int(re.search(r'\d+', first.ref).group())
        second_number = int(re.search(r'\d+', second.ref).group())
        self.assertEqual(second_number, first_number + 1)
        self.assertEqual(first.display_name, f'{first.ref} Printer down')

    def test_default_stage_is_first_team_stage(self):
        self.assertEqual(self._create_ticket().stage_id, self.stage_open)

    def test_changing_team_resets_invalid_stage(self):
        ticket = self._create_ticket()
        other_stage = self.env['helpdesk.stage'].create({'name': 'Other'})
        other_team = self.env['helpdesk.team'].create({
            'name': 'Other Team',
            'stage_ids': [(6, 0, other_stage.ids)],
        })
        ticket.team_id = other_team
        self.assertEqual(ticket.stage_id, other_stage)

    def test_close_date_follows_stage(self):
        ticket = self._create_ticket()
        self.assertFalse(ticket.close_date)
        ticket.stage_id = self.stage_closed
        self.assertTrue(ticket.close_date)
        ticket.stage_id = self.stage_open
        self.assertFalse(ticket.close_date)

    def test_stage_change_resets_kanban_state(self):
        ticket = self._create_ticket()
        ticket.kanban_state = 'blocked'
        ticket.stage_id = self.stage_closed
        self.assertEqual(ticket.kanban_state, 'normal')

    def test_team_counts(self):
        self.team.assignment_method = 'manual'
        self._create_ticket(priority='3')
        self._create_ticket(user_ids=self.user_a.ids)
        self._create_ticket(stage_id=self.stage_closed.id, priority='3')
        self.team.invalidate_recordset()
        self.assertEqual(self.team.open_ticket_count, 2)
        self.assertEqual(self.team.urgent_ticket_count, 1)
        self.assertEqual(self.team.unassigned_ticket_count, 1)
