from odoo.tests import tagged

from odoo.addons.mail.tests.common import MailCommon

from .common import setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestStageMail(MailCommon):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        cls.customer = cls.env['res.partner'].create({'name': 'Mail Customer', 'email': 'mail.customer@example.com'})
        cls.template_open = cls.env['mail.template'].create({
            'name': 'Test opened',
            'model_id': cls.env['ir.model']._get_id('helpdesk.ticket'),
            'subject': 'Opened {{ object.ref }}',
            'partner_to': '{{ object.partner_id.id }}',
            'body_html': '<p>We got it</p>',
        })
        cls.template_closed = cls.env['mail.template'].create({
            'name': 'Test closed',
            'model_id': cls.env['ir.model']._get_id('helpdesk.ticket'),
            'subject': 'Closed {{ object.ref }}',
            'partner_to': '{{ object.partner_id.id }}',
            'body_html': '<p>All done</p>',
        })
        cls.stage_open.mail_template_id = cls.template_open
        cls.stage_closed.mail_template_id = cls.template_closed

    def _messages_with_subject(self, ticket, subject):
        return ticket.message_ids.filtered(lambda message: message.subject == subject)

    def test_template_sent_on_creation(self):
        with self.mock_mail_gateway():
            ticket = self.env['helpdesk.ticket'].create({
                'name': 'Hello', 'team_id': self.team.id, 'partner_id': self.customer.id,
            })
            self.flush_tracking()
        message = self._messages_with_subject(ticket, f'Opened {ticket.ref}')
        self.assertEqual(len(message), 1)
        self.assertIn(self.customer, message.partner_ids)

    def test_template_sent_on_stage_change(self):
        with self.mock_mail_gateway():
            ticket = self.env['helpdesk.ticket'].create({
                'name': 'Hello', 'team_id': self.team.id, 'partner_id': self.customer.id,
            })
            self.flush_tracking()
            ticket.stage_id = self.stage_closed
            self.flush_tracking()
        self.assertEqual(len(self._messages_with_subject(ticket, f'Closed {ticket.ref}')), 1)

    def test_no_template_no_email(self):
        self.stage_closed.mail_template_id = False
        with self.mock_mail_gateway():
            ticket = self.env['helpdesk.ticket'].create({
                'name': 'Hello', 'team_id': self.team.id, 'partner_id': self.customer.id,
            })
            self.flush_tracking()
            count = len(ticket.message_ids)
            ticket.stage_id = self.stage_closed
            self.flush_tracking()
        new_messages = ticket.message_ids[:len(ticket.message_ids) - count]
        self.assertFalse(new_messages.filtered(lambda message: message.subject))

    def test_default_templates_render(self):
        """The shipped templates must render for a ticket without errors."""
        ticket = self.env['helpdesk.ticket'].create({
            'name': 'Render me', 'team_id': self.team.id, 'partner_id': self.customer.id,
        })
        for xmlid in ('mail_template_ticket_received', 'mail_template_ticket_closed', 'mail_template_rating_request'):
            template = self.env.ref(f'nifty_helpdesk.{xmlid}')
            body = template._render_field('body_html', ticket.ids)[ticket.id]
            self.assertIn(ticket.ref, body)

    def test_no_email_when_ticket_has_no_recipient(self):
        with self.mock_mail_gateway():
            ticket = self.env['helpdesk.ticket'].create({'name': 'Nobody to tell', 'team_id': self.team.id})
            self.flush_tracking()
        self.assertFalse(self._messages_with_subject(ticket, f'Opened {ticket.ref}'))
