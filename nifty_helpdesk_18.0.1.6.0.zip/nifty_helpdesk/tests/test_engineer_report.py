import io
import zipfile
from datetime import date, datetime

from odoo.exceptions import UserError
from odoo.tests import TransactionCase, new_test_user, tagged

from .common import setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestEngineerReport(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        cls.team.visibility = 'internal'
        (cls.user_a | cls.user_b).write({'tz': 'UTC'})
        cls.user_a.name = 'Alice Engineer'
        cls.user_b.name = 'Bob Engineer'
        Ticket = cls.env['helpdesk.ticket']

        def ticket(name, when, users, **extra):
            return Ticket.create({
                'name': name, 'team_id': cls.team.id, 'scheduled_date': when,
                'user_ids': [(6, 0, users.ids)], **extra,
            })

        cls.t_alice = ticket('Alice job', datetime(2026, 11, 3, 9, 0), cls.user_a)
        cls.t_shared = ticket('Shared job', datetime(2026, 11, 4, 14, 0), cls.user_a | cls.user_b)
        cls.t_closed = ticket('Closed job', datetime(2026, 11, 5, 8, 0), cls.user_b, stage_id=cls.stage_closed.id)
        cls.t_outside = ticket('Outside job', datetime(2026, 11, 20, 8, 0), cls.user_a)
        cls.t_unassigned = Ticket.create({
            'name': 'Nobody', 'team_id': cls.team.id, 'scheduled_date': datetime(2026, 11, 4, 10, 0),
        })

    def _report(self, user=None, **values):
        Report = self.env['helpdesk.engineer.report']
        if user:
            Report = Report.with_user(user)
        # Limit to the test team: the database may hold other scheduled tickets.
        return Report.with_context(tz='UTC').create({
            'date_from': date(2026, 11, 1), 'date_to': date(2026, 11, 10),
            'team_ids': [(6, 0, self.team.ids)], **values,
        })

    def test_groups_by_engineer_with_shared_tickets_under_each(self):
        groups = dict(self._report(user_ids=[(6, 0, [])])._get_groups())
        self.assertEqual(groups[self.user_a], self.t_alice | self.t_shared)
        self.assertEqual(groups[self.user_b], self.t_shared | self.t_closed)
        listed = groups[self.user_a] | groups[self.user_b]
        self.assertNotIn(self.t_outside, listed)
        self.assertNotIn(self.t_unassigned, listed)

    def test_engineer_filter_and_open_only(self):
        report = self._report(user_ids=[(6, 0, self.user_b.ids)], include_closed=False)
        self.assertEqual(dict(report._get_groups()), {self.user_b: self.t_shared})

    def test_date_range_uses_user_time_zone(self):
        # 3 Nov 09:00 UTC is still 3 Nov in Dubai, but 4 Nov 01:00 local would not be.
        report = self.env['helpdesk.engineer.report'].with_context(tz='Asia/Dubai').create({
            'date_from': date(2026, 11, 3), 'date_to': date(2026, 11, 3), 'user_ids': [(6, 0, [])],
            'team_ids': [(6, 0, self.team.ids)],
        })
        start, end = report._utc_bounds()
        self.assertEqual(start, datetime(2026, 11, 2, 20, 0))
        self.assertEqual(end, datetime(2026, 11, 3, 20, 0))
        self.assertEqual(report._get_tickets(), self.t_alice)

    def test_default_engineer_is_current_helpdesk_user(self):
        report = self.env['helpdesk.engineer.report'].with_user(self.user_a).create({
            'date_from': date(2026, 11, 1), 'date_to': date(2026, 11, 10),
        })
        self.assertEqual(report.user_ids, self.user_a)
        manager = new_test_user(self.env, login='hd_report_manager', groups='nifty_helpdesk.group_helpdesk_manager')
        report = self.env['helpdesk.engineer.report'].with_user(manager).create({
            'date_from': date(2026, 11, 1), 'date_to': date(2026, 11, 10),
        })
        self.assertFalse(report.user_ids)

    def test_invalid_range_is_refused(self):
        with self.assertRaises(UserError):
            self._report(date_from=date(2026, 11, 10), date_to=date(2026, 11, 1))

    def test_empty_period_print_and_export_are_refused(self):
        report = self._report(date_from=date(2025, 1, 1), date_to=date(2025, 1, 2))
        with self.assertRaises(UserError):
            report.action_print()
        with self.assertRaises(UserError):
            report.action_export_xlsx()

    def test_view_tickets_opens_filtered_ticket_list(self):
        action = self._report(user_ids=[(6, 0, self.user_a.ids)]).action_view_tickets()
        found = self.env['helpdesk.ticket'].search(action['domain'])
        self.assertEqual(found, self.t_alice | self.t_shared)

    def test_view_hours_lists_each_engineers_own_sessions(self):
        Worklog = self.env['helpdesk.ticket.worklog']
        own = Worklog.create({'ticket_id': self.t_shared.id, 'user_id': self.user_a.id,
                              'start': datetime(2026, 11, 4, 14), 'duration': 0.75})
        colleague = Worklog.create({'ticket_id': self.t_shared.id, 'user_id': self.user_b.id,
                                    'start': datetime(2026, 11, 4, 14), 'duration': 1.5})
        outside = Worklog.create({'ticket_id': self.t_outside.id, 'user_id': self.user_a.id,
                                  'start': datetime(2026, 11, 20, 8), 'duration': 2})

        action = self._report(user_ids=[(6, 0, self.user_a.ids)]).action_view()
        self.assertEqual(action['res_model'], 'helpdesk.ticket.worklog')
        self.assertEqual(Worklog.search(action['domain']), own)
        self.assertTrue(action['context']['search_default_group_user'])

        everyone = self._report(user_ids=[(6, 0, [])]).action_view()
        found = Worklog.search(everyone['domain'])
        self.assertEqual(found, own | colleague, 'Tickets outside the period are left out')
        self.assertNotIn(outside, found)
        groups = dict(Worklog._read_group(everyone['domain'], ['user_id'], ['duration:sum']))
        self.assertEqual(groups, {self.user_a: 0.75, self.user_b: 1.5})

    def test_excel_export_contains_one_row_per_engineer_and_ticket(self):
        report = self._report(user_ids=[(6, 0, [])])
        action = report.action_export_xlsx()
        attachment_id = int(action['url'].split('/web/content/')[1].split('?')[0])
        attachment = self.env['ir.attachment'].browse(attachment_id)
        self.assertTrue(attachment.name.endswith('.xlsx'))
        with zipfile.ZipFile(io.BytesIO(attachment.raw)) as archive:
            strings = archive.read('xl/sharedStrings.xml').decode()
            sheet = archive.read('xl/worksheets/sheet1.xml').decode()
        for ticket in self.t_alice | self.t_shared | self.t_closed:
            self.assertIn(ticket.ref, strings)
        self.assertNotIn(self.t_outside.ref, strings)
        # Header row (4), then Alice x2 + her total, Bob x2 + his total.
        self.assertIn('<row r="10"', sheet)
        self.assertNotIn('<row r="11"', sheet)

    def test_pdf_template_renders(self):
        report = self._report(user_ids=[(6, 0, [])])
        html, _format = self.env['ir.actions.report']._render_qweb_html(
            'nifty_helpdesk.action_report_engineer_tickets', report.ids,
        )
        html = html.decode()
        self.assertIn('Alice Engineer', html)
        self.assertIn('Bob Engineer', html)
        self.assertIn(self.t_shared.ref, html)
        self.assertNotIn(self.t_outside.ref, html)
