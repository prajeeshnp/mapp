from odoo.exceptions import ValidationError
from odoo.tests import HttpCase, tagged

from odoo.addons.mail.tests.common import MailCommon

from .common import setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestRating(MailCommon):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls, visibility='portal')
        cls.customer = cls.env['res.partner'].create({'name': 'Rater', 'email': 'rater@example.com'})
        cls.stage_closed.rating_template_id = cls.env.ref('nifty_helpdesk.mail_template_rating_request')
        cls.ticket = cls.env['helpdesk.ticket'].create({
            'name': 'Rate me', 'team_id': cls.team.id, 'partner_id': cls.customer.id,
        })

    def _ratings(self):
        return self.env['rating.rating'].search([('res_model', '=', 'helpdesk.ticket'), ('res_id', '=', self.ticket.id)])

    def test_no_request_when_ratings_off(self):
        self.team.use_rating = False
        with self.mock_mail_gateway():
            self.ticket.stage_id = self.stage_closed
            self.flush_tracking()
        self.assertFalse(self._ratings())

    def test_request_sent_when_ratings_on(self):
        self.team.use_rating = True
        with self.mock_mail_gateway():
            self.ticket.stage_id = self.stage_closed
            self.flush_tracking()
        rating = self._ratings()
        self.assertEqual(len(rating), 1)
        self.assertEqual(rating.partner_id, self.customer)
        self.assertEqual(rating.parent_res_model, 'helpdesk.team')
        self.assertEqual(rating.parent_res_id, self.team.id)

    def test_applied_rating_updates_ticket_and_team(self):
        self.team.use_rating = True
        with self.mock_mail_gateway():
            self.ticket.stage_id = self.stage_closed
            self.flush_tracking()
            token = self._ratings().access_token
            self.ticket.rating_apply(5, token=token, feedback='Great help')
        self.assertEqual(self.ticket.rating_last_value, 5)
        self.team.invalidate_recordset()
        self.assertEqual(self.team.rating_percentage_satisfaction, 100)

    def test_publish_requires_portal_and_ratings(self):
        self.team.use_rating = False
        with self.assertRaises(ValidationError):
            self.team.rating_public = True
        self.team.write({'use_rating': True, 'rating_public': True})
        self.team.visibility = 'internal'
        self.assertFalse(self.team.rating_public)


@tagged('post_install', '-at_install')
class TestRatingPage(HttpCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls, visibility='portal')

    def test_page_only_exists_when_published(self):
        response = self.url_open(f'/helpdesk/rating/{self.team.id}')
        self.assertEqual(response.status_code, 404)
        self.team.write({'use_rating': True, 'rating_public': True})
        response = self.url_open(f'/helpdesk/rating/{self.team.id}')
        self.assertEqual(response.status_code, 200)
        self.assertIn('Test Team', response.text)
