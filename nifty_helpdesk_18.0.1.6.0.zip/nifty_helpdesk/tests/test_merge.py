from odoo.exceptions import UserError
from odoo.tests import TransactionCase, tagged

from .common import setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestMerge(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        Tag = cls.env['helpdesk.tag']
        cls.tag_a = Tag.create({'name': 'Merge A'})
        cls.tag_b = Tag.create({'name': 'Merge B'})
        cls.customer = cls.env['res.partner'].create({'name': 'Merge Customer'})
        cls.other_follower = cls.env['res.partner'].create({'name': 'Watcher'})
        Ticket = cls.env['helpdesk.ticket']
        cls.first = Ticket.create({
            'name': 'Printer broken', 'team_id': cls.team.id, 'partner_id': cls.customer.id,
            'tag_ids': [(6, 0, cls.tag_a.ids)], 'description': '<p>First text</p>',
        })
        cls.second = Ticket.create({
            'name': 'Printer still broken', 'team_id': cls.team.id,
            'tag_ids': [(6, 0, cls.tag_b.ids)], 'description': '<p>Second text</p>',
        })
        cls.second.message_subscribe(partner_ids=cls.other_follower.ids)
        cls.second.message_post(body='Message on second', subtype_xmlid='mail.mt_comment')

    def _wizard(self, tickets, target=None):
        wizard = self.env['helpdesk.ticket.merge'].with_context(
            active_model='helpdesk.ticket', active_ids=tickets.ids,
        ).create({})
        if target:
            wizard.target_ticket_id = target
        return wizard

    def test_default_target_is_oldest(self):
        self.assertEqual(self._wizard(self.first | self.second).target_ticket_id, self.first)

    def test_merge_moves_everything_and_archives(self):
        self._wizard(self.first | self.second).action_merge()
        self.assertFalse(self.second.active)
        self.assertTrue(self.first.active)
        self.assertEqual(self.first.tag_ids, self.tag_a | self.tag_b)
        self.assertIn(self.other_follower, self.first.message_partner_ids)
        self.assertTrue(self.first.message_ids.filtered(lambda message: 'Message on second' in (message.body or '')))
        self.assertIn('Second text', self.first.description)
        self.assertIn('First text', self.first.description)

    def test_single_ticket_is_refused(self):
        with self.assertRaises(UserError):
            self._wizard(self.first).action_merge()
