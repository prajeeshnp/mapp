from datetime import timedelta

from odoo import fields
from odoo.tests import TransactionCase, new_test_user, tagged
from odoo.tools import mute_logger

from .common import create_always_open_calendar, setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestReports(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        cls.team.resource_calendar_id = create_always_open_calendar(cls.env)
        cls.env['helpdesk.sla'].create({
            'name': 'Report SLA', 'team_id': cls.team.id, 'priority': '3',
            'stage_id': cls.stage_closed.id, 'time': 2,
            'resource_calendar_id': cls.team.resource_calendar_id.id,
        })
        Ticket = cls.env['helpdesk.ticket']
        cls.open_ticket = Ticket.create({'name': 'Still open', 'team_id': cls.team.id, 'priority': '3'})
        cls.closed_ticket = Ticket.create({
            'name': 'Done', 'team_id': cls.team.id, 'priority': '3', 'user_ids': cls.user_a.ids,
        })
        cls.closed_ticket.stage_id = cls.stage_closed
        cls.open_ticket.sla_status_ids.deadline = fields.Datetime.now() - timedelta(minutes=1)
        cls.env['helpdesk.sla.status']._cron_mark_failed()
        cls.env.flush_all()

    def test_ticket_analysis_counts_and_nulls(self):
        Analysis = self.env['helpdesk.ticket.analysis']
        rows = Analysis.search([('team_id', '=', self.team.id)])
        self.assertEqual(rows.ticket_id, self.open_ticket | self.closed_ticket)
        open_row = rows.filtered(lambda row: row.ticket_id == self.open_ticket)
        closed_row = rows.filtered(lambda row: row.ticket_id == self.closed_ticket)
        self.assertFalse(open_row.is_closed)
        self.assertTrue(closed_row.is_closed)
        self.assertTrue(open_row.sla_failed)
        self.assertGreaterEqual(open_row.open_hours, 0)
        # Averages must ignore tickets that were never closed.
        [(count, close_avg)] = Analysis._read_group(
            [('team_id', '=', self.team.id)], [], ['__count', 'close_hours:avg'],
        )
        self.assertEqual(count, 2)
        self.assertAlmostEqual(close_avg, self.closed_ticket.close_hours, places=4)

    def test_sla_analysis_status(self):
        rows = self.env['helpdesk.sla.analysis'].search([('team_id', '=', self.team.id)])
        by_ticket = {row.ticket_id: row for row in rows}
        self.assertEqual(by_ticket[self.open_ticket].status, 'failed')
        self.assertEqual(by_ticket[self.open_ticket].failed_count, 1)
        self.assertEqual(by_ticket[self.closed_ticket].status, 'reached')
        self.assertEqual(by_ticket[self.closed_ticket].failed_count, 0)

    @mute_logger('odoo.addons.base.models.ir_rule')
    def test_reports_follow_ticket_visibility(self):
        outsider = new_test_user(self.env, login='hd_report_outsider', groups='nifty_helpdesk.group_helpdesk_user')
        for model in ('helpdesk.ticket.analysis', 'helpdesk.sla.analysis'):
            self.assertFalse(self.env[model].with_user(outsider).search([('team_id', '=', self.team.id)]))
            self.assertTrue(self.env[model].with_user(self.user_a).search([('team_id', '=', self.team.id)]))
