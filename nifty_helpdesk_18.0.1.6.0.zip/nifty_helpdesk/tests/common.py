from odoo.tests import new_test_user


def setup_helpdesk_data(cls, visibility='invited'):
    """Create a team with its own stages and two members on ``cls``."""
    cls.stage_open = cls.env['helpdesk.stage'].create({'name': 'Test Open', 'sequence': 1})
    cls.stage_closed = cls.env['helpdesk.stage'].create({
        'name': 'Test Closed',
        'sequence': 2,
        'is_closed': True,
    })
    cls.user_a = new_test_user(cls.env, login='hd_user_a', groups='nifty_helpdesk.group_helpdesk_user')
    cls.user_b = new_test_user(cls.env, login='hd_user_b', groups='nifty_helpdesk.group_helpdesk_user')
    cls.team = cls.env['helpdesk.team'].create({
        'name': 'Test Team',
        'visibility': visibility,
        'member_ids': [(6, 0, (cls.user_a | cls.user_b).ids)],
        'stage_ids': [(6, 0, (cls.stage_open | cls.stage_closed).ids)],
    })


def create_always_open_calendar(env):
    """A calendar that works every hour of every day, so deadlines are easy to predict."""
    return env['resource.calendar'].create({
        'name': 'Always open',
        'tz': 'UTC',
        'attendance_ids': [(5, 0, 0)] + [
            (0, 0, {'name': f'Day {day}', 'dayofweek': str(day), 'hour_from': 0, 'hour_to': 24,
                    'day_period': 'morning'})
            for day in range(7)
        ],
    })
