import re
from datetime import timedelta

from odoo import fields
from odoo.tests import HttpCase, TransactionCase, new_test_user, tagged

from .common import setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestAutoClose(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        cls.stage_waiting = cls.env['helpdesk.stage'].create({'name': 'Waiting', 'sequence': 1})
        cls.team.stage_ids = [(4, cls.stage_waiting.id)]
        cls.team.write({'auto_close': True, 'auto_close_days': 5})

    def _ticket(self, days_idle, stage=None):
        ticket = self.env['helpdesk.ticket'].create({
            'name': f'Idle {days_idle}', 'team_id': self.team.id,
            'stage_id': (stage or self.stage_open).id,
        })
        ticket.last_activity_date = fields.Datetime.now() - timedelta(days=days_idle)
        return ticket

    def test_closing_stage_defaults_to_first_closed_stage(self):
        self.assertEqual(self.team.closing_stage_id, self.stage_closed)

    def test_inactive_ticket_is_closed(self):
        idle = self._ticket(6)
        recent = self._ticket(2)
        self.env['helpdesk.team']._cron_close_inactive_tickets()
        self.assertEqual(idle.stage_id, self.stage_closed)
        self.assertEqual(recent.stage_id, self.stage_open)
        self.assertIn('without activity', idle.message_ids[0].body)

    def test_only_watched_stages_are_closed(self):
        self.team.auto_close_stage_ids = self.stage_waiting
        watched = self._ticket(10, self.stage_waiting)
        unwatched = self._ticket(10, self.stage_open)
        self.env['helpdesk.team']._cron_close_inactive_tickets()
        self.assertEqual(watched.stage_id, self.stage_closed)
        self.assertEqual(unwatched.stage_id, self.stage_open)

    def test_team_without_auto_close_is_ignored(self):
        self.team.auto_close = False
        idle = self._ticket(30)
        self.env['helpdesk.team']._cron_close_inactive_tickets()
        self.assertEqual(idle.stage_id, self.stage_open)

    def test_customer_message_counts_as_activity_but_note_does_not(self):
        ticket = self._ticket(10)
        old = ticket.last_activity_date
        ticket.message_post(body='Internal only', subtype_xmlid='mail.mt_note', message_type='comment')
        self.assertEqual(ticket.last_activity_date, old)
        ticket.message_post(body='Hello customer', subtype_xmlid='mail.mt_comment', message_type='comment')
        self.assertGreater(ticket.last_activity_date, old)

    def test_agent_reply_sets_first_response(self):
        ticket = self._ticket(0)
        ticket.with_user(self.user_a).message_post(
            body='On it', subtype_xmlid='mail.mt_comment', message_type='comment',
        )
        self.assertTrue(ticket.first_response_date)


@tagged('post_install', '-at_install')
class TestCustomerClose(HttpCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls, visibility='portal')
        cls.portal_user = new_test_user(cls.env, login='hd_close_portal', groups='base.group_portal')
        cls.ticket = cls.env['helpdesk.ticket'].create({
            'name': 'Close me please',
            'team_id': cls.team.id,
            'partner_id': cls.portal_user.partner_id.id,
        })

    def _csrf_from(self, url):
        # The Close form only renders when closing is allowed, so read the
        # session's token from a page that always has one.
        allowed = self.team.allow_customer_close
        self.team.allow_customer_close = True
        page = self.url_open(url).text
        self.team.allow_customer_close = allowed
        return re.search(r'name="csrf_token" value="([^"]+)"', page).group(1)

    def _post_close(self, **data):
        return self.url_open(
            f'/my/tickets/{self.ticket.id}/close',
            data={'csrf_token': self._csrf_from(self.ticket.get_portal_url()), **data},
        )

    def test_customer_can_close_when_allowed(self):
        self.team.allow_customer_close = True
        self.authenticate('hd_close_portal', 'hd_close_portal')
        page = self.url_open(self.ticket.access_url)
        self.assertIn('Close ticket', page.text)
        self._post_close()
        self.ticket.invalidate_recordset()
        self.assertEqual(self.ticket.stage_id, self.stage_closed)
        note = self.ticket.message_ids.filtered(lambda message: 'customer closed' in (message.body or ''))
        self.assertEqual(note.author_id, self.portal_user.partner_id)

    def test_customer_cannot_close_when_not_allowed(self):
        self.team.allow_customer_close = False
        self.authenticate('hd_close_portal', 'hd_close_portal')
        self.assertNotIn('Close ticket', self.url_open(self.ticket.access_url).text)
        response = self._post_close()
        self.assertEqual(response.status_code, 200)
        self.ticket.invalidate_recordset()
        self.assertEqual(self.ticket.stage_id, self.stage_open)

    def test_token_link_can_close(self):
        self.team.allow_customer_close = True
        token = self.ticket._portal_ensure_token()
        self._post_close(access_token=token)
        self.ticket.invalidate_recordset()
        self.assertEqual(self.ticket.stage_id, self.stage_closed)
