import io
import zipfile
from datetime import date, datetime

from odoo.exceptions import AccessError, ValidationError
from odoo.tests import TransactionCase, new_test_user, tagged
from odoo.tools import mute_logger

from .common import setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestWorklog(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        cls.team.visibility = 'invited'
        (cls.user_a | cls.user_b).write({'tz': 'UTC'})
        cls.ticket = cls.env['helpdesk.ticket'].create({
            'name': 'Server room visit', 'team_id': cls.team.id,
            'scheduled_date': datetime(2026, 11, 3, 9), 'user_ids': [(6, 0, (cls.user_a | cls.user_b).ids)],
        })
        cls.Worklog = cls.env['helpdesk.ticket.worklog']

    def _log(self, user, start, end=None, duration=None, ticket=None):
        values = {'ticket_id': (ticket or self.ticket).id, 'user_id': user.id, 'start': start}
        if end:
            values['end'] = end
        if duration is not None:
            values['duration'] = duration
        return self.Worklog.with_user(user).create(values)

    def test_duration_from_start_and_end(self):
        log = self._log(self.user_a, datetime(2026, 11, 3, 9, 0), datetime(2026, 11, 3, 11, 30))
        self.assertAlmostEqual(log.duration, 2.5)

    def test_duration_only_session(self):
        log = self._log(self.user_a, datetime(2026, 11, 3, 9), duration=1.25)
        self.assertFalse(log.end)
        self.assertAlmostEqual(log.duration, 1.25)

    def test_invalid_sessions_are_refused(self):
        with self.assertRaises(ValidationError):
            self._log(self.user_a, datetime(2026, 11, 3, 11), datetime(2026, 11, 3, 10))
        with self.assertRaises(ValidationError):
            self._log(self.user_a, datetime(2026, 11, 3, 9), duration=0)
        with self.assertRaises(ValidationError):
            self._log(self.user_a, datetime(2026, 11, 3, 9), duration=30)

    def test_several_sessions_and_engineers_add_up_on_the_ticket(self):
        self._log(self.user_a, datetime(2026, 11, 3, 9), datetime(2026, 11, 3, 10))
        self._log(self.user_a, datetime(2026, 11, 4, 9), datetime(2026, 11, 4, 9, 30))
        self._log(self.user_b, datetime(2026, 11, 3, 9), duration=2)
        self.assertAlmostEqual(self.ticket.total_hours, 3.5)
        by_user = self.ticket._hours_by_engineer()[self.ticket.id]
        self.assertAlmostEqual(by_user[self.user_a], 1.5)
        self.assertAlmostEqual(by_user[self.user_b], 2.0)

    def test_total_updates_when_a_session_changes_or_is_removed(self):
        log = self._log(self.user_a, datetime(2026, 11, 3, 9), duration=2)
        log.with_user(self.user_a).duration = 3
        self.assertAlmostEqual(self.ticket.total_hours, 3)
        log.with_user(self.user_a).unlink()
        self.assertAlmostEqual(self.ticket.total_hours, 0)

    @mute_logger('odoo.addons.base.models.ir_rule')
    def test_engineers_change_only_their_own_sessions(self):
        log_b = self._log(self.user_b, datetime(2026, 11, 3, 9), duration=1)
        self.assertEqual(log_b.with_user(self.user_a).duration, 1, 'Colleagues can read each other\'s time')
        with self.assertRaises(AccessError):
            log_b.with_user(self.user_a).write({'duration': 5})
        with self.assertRaises(AccessError):
            log_b.with_user(self.user_a).unlink()
        with self.assertRaises(AccessError):
            self.Worklog.with_user(self.user_a).create({
                'ticket_id': self.ticket.id, 'user_id': self.user_b.id,
                'start': datetime(2026, 11, 3, 9), 'duration': 1,
            })

    def test_manager_can_log_for_anyone(self):
        manager = new_test_user(self.env, login='hd_worklog_manager', groups='nifty_helpdesk.group_helpdesk_manager')
        log = self.Worklog.with_user(manager).create({
            'ticket_id': self.ticket.id, 'user_id': self.user_b.id,
            'start': datetime(2026, 11, 3, 9), 'duration': 1,
        })
        log.with_user(manager).duration = 2
        self.assertAlmostEqual(self.ticket.total_hours, 2)

    @mute_logger('odoo.addons.base.models.ir_rule')
    def test_sessions_hidden_with_the_ticket(self):
        self._log(self.user_a, datetime(2026, 11, 3, 9), duration=1)
        outsider = new_test_user(self.env, login='hd_worklog_outsider', groups='nifty_helpdesk.group_helpdesk_user')
        self.assertFalse(self.Worklog.with_user(outsider).search([('ticket_id', '=', self.ticket.id)]))

    def test_engineer_report_shows_own_and_total_hours(self):
        self._log(self.user_a, datetime(2026, 11, 3, 9), duration=1.5)
        self._log(self.user_b, datetime(2026, 11, 3, 9), duration=0.5)
        report = self.env['helpdesk.engineer.report'].with_context(tz='UTC').create({
            'date_from': date(2026, 11, 1), 'date_to': date(2026, 11, 10),
            'user_ids': [(6, 0, [])], 'team_ids': [(6, 0, self.team.ids)],
        })
        groups = {group['engineer']: group for group in report._get_report_data()}
        self.assertAlmostEqual(groups[self.user_a]['hours'], 1.5)
        self.assertAlmostEqual(groups[self.user_b]['hours'], 0.5)
        self.assertAlmostEqual(groups[self.user_a]['lines'][0]['ticket'].total_hours, 2.0)

        html, _format = self.env['ir.actions.report']._render_qweb_html(
            'nifty_helpdesk.action_report_engineer_tickets', report.ids,
        )
        html = html.decode()
        self.assertIn('1:30', html)
        self.assertIn('2:00', html)
        self.assertIn('Ticket Total', html)

        action = report.action_export_xlsx()
        attachment = self.env['ir.attachment'].browse(int(action['url'].split('/web/content/')[1].split('?')[0]))
        with zipfile.ZipFile(io.BytesIO(attachment.raw)) as archive:
            strings = archive.read('xl/sharedStrings.xml').decode()
        self.assertIn('Engineer Hours', strings)
        self.assertIn('Ticket Total Hours', strings)
        self.assertIn(f'Total {self.user_a.name}', strings)

    def test_ticket_analysis_sums_time_spent(self):
        self._log(self.user_a, datetime(2026, 11, 3, 9), duration=2)
        self.env.flush_all()
        [(hours,)] = self.env['helpdesk.ticket.analysis']._read_group(
            [('ticket_id', '=', self.ticket.id)], [], ['total_hours:sum'],
        )
        self.assertAlmostEqual(hours, 2)
