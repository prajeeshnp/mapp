from datetime import timedelta

from odoo import fields
from odoo.tests import TransactionCase, new_test_user, tagged

from .common import setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestTeamOverview(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        cls.team.visibility = 'invited'
        Ticket = cls.env['helpdesk.ticket']
        cls.t_urgent = Ticket.create({'name': 'Urgent open', 'team_id': cls.team.id, 'priority': '3',
                                      'user_ids': [(6, 0, cls.user_a.ids)]})
        cls.t_low = Ticket.create({'name': 'Low unassigned', 'team_id': cls.team.id, 'priority': '0'})
        cls.t_done = Ticket.create({'name': 'Done', 'team_id': cls.team.id, 'priority': '1',
                                    'user_ids': [(6, 0, cls.user_b.ids)]})
        cls.t_done.stage_id = cls.stage_closed
        cls.t_old = Ticket.create({'name': 'Old', 'team_id': cls.team.id})
        old = fields.Datetime.now() - timedelta(days=45)
        cls.env.cr.execute('UPDATE helpdesk_ticket SET create_date = %s WHERE id = %s', (old, cls.t_old.id))
        cls.env.invalidate_all()

    def _stats(self, user=None):
        team = self.team.with_context(tz='UTC')
        if user:
            team = team.with_user(user)
        team.invalidate_recordset(['overview_stats'])
        return team.overview_stats

    def test_status_counts_last_30_days(self):
        status = {row['key']: row['count'] for row in self._stats()['status']}
        self.assertEqual(status, {'resolved': 1, 'in_progress': 1, 'unassigned': 1},
                         'The 45-day-old ticket is outside the 30-day window')

    def test_open_by_priority(self):
        priority = {row['key']: row['count'] for row in self._stats()['priority']}
        # Open tickets only: urgent, low, and the old one (low, open).
        self.assertEqual(priority, {'0': 2, '1': 0, '2': 0, '3': 1})

    def test_trend_has_seven_days_ending_today(self):
        trend = self._stats()['trend']
        self.assertEqual(len(trend), 7)
        today = fields.Date.context_today(self.team.with_context(tz='UTC'))
        self.assertEqual(trend[-1]['key'], today.isoformat())
        self.assertEqual(trend[-1]['created'], 3)
        self.assertEqual(trend[-1]['resolved'], 1)
        self.assertEqual(sum(day['created'] for day in trend), 3)

    def test_segments_open_matching_tickets(self):
        Ticket = self.env['helpdesk.ticket']
        team = self.team.with_context(tz='UTC')
        checks = [
            ('status', 'resolved', self.t_done),
            ('status', 'unassigned', self.t_low),
            ('priority', '3', self.t_urgent),
            ('priority', '0', self.t_low | self.t_old),
            ('resolved', fields.Date.context_today(team).isoformat(), self.t_done),
        ]
        for kind, key, expected in checks:
            action = team.action_view_overview_segment(kind, key)
            self.assertEqual(Ticket.search(action['domain']), expected, (kind, key))

    def test_respects_ticket_visibility(self):
        outsider = new_test_user(self.env, login='hd_overview_outsider', groups='nifty_helpdesk.group_helpdesk_user')
        self.team.visibility = 'internal'
        self.assertEqual(sum(row['count'] for row in self._stats(user=outsider)['priority']), 3)
