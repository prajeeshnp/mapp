from odoo.tests import TransactionCase, tagged

from .common import setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestAssignment(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        cls.members = (cls.user_a | cls.user_b).sorted('id')

    def _create_ticket(self, **values):
        return self.env['helpdesk.ticket'].create({'name': 'Issue', 'team_id': self.team.id, **values})

    def test_manual_leaves_ticket_unassigned(self):
        self.team.assignment_method = 'manual'
        self.assertFalse(self._create_ticket().user_ids)

    def test_round_robin_cycles_and_wraps(self):
        self.team.assignment_method = 'round_robin'
        assignees = [self._create_ticket().user_ids for _ in range(3)]
        self.assertEqual(assignees, [self.members[0], self.members[1], self.members[0]])

    def test_round_robin_batch_create(self):
        self.team.assignment_method = 'round_robin'
        tickets = self.env['helpdesk.ticket'].create([
            {'name': f'Issue {index}', 'team_id': self.team.id} for index in range(2)
        ])
        self.assertEqual(tickets[0].user_ids, self.members[0])
        self.assertEqual(tickets[1].user_ids, self.members[1])

    def test_round_robin_skips_removed_member(self):
        self.team.assignment_method = 'round_robin'
        self.assertEqual(self._create_ticket().user_ids, self.members[0])
        self.team.member_ids = [(3, self.members[1].id)]
        self.assertEqual(self._create_ticket().user_ids, self.members[0])

    def test_explicit_user_is_kept_and_does_not_advance_turn(self):
        self.team.assignment_method = 'round_robin'
        ticket = self._create_ticket(user_ids=self.members[1].ids)
        self.assertEqual(ticket.user_ids, self.members[1])
        self.assertFalse(self.team.last_assigned_user_id)

    def test_balanced_picks_member_with_fewest_open_tickets(self):
        self.team.assignment_method = 'balanced'
        self._create_ticket(user_ids=self.members[0].ids)
        self.assertEqual(self._create_ticket().user_ids, self.members[1])

    def test_balanced_ignores_closed_tickets(self):
        self.team.assignment_method = 'balanced'
        self._create_ticket(user_ids=self.members[0].ids, stage_id=self.stage_closed.id)
        self._create_ticket(user_ids=self.members[1].ids)
        self.assertEqual(self._create_ticket().user_ids, self.members[0])

    def test_balanced_batch_create_spreads_tickets(self):
        self.team.assignment_method = 'balanced'
        tickets = self.env['helpdesk.ticket'].create([
            {'name': f'Issue {index}', 'team_id': self.team.id} for index in range(2)
        ])
        self.assertEqual(tickets.user_ids, self.members)

    def test_empty_member_list_uses_all_helpdesk_users(self):
        self.team.write({'assignment_method': 'round_robin', 'member_ids': [(5, 0, 0)]})
        group = self.env.ref('nifty_helpdesk.group_helpdesk_user')
        expected = self.env['res.users'].search([('groups_id', 'in', group.ids), ('share', '=', False)])
        ticket = self._create_ticket()
        self.assertIn(ticket.user_ids, expected)
        self.assertEqual(ticket.assignable_user_ids, expected)

    def test_archived_member_is_skipped(self):
        self.team.assignment_method = 'round_robin'
        self.members[0].active = False
        self.assertEqual(self._create_ticket().user_ids, self.members[1])
