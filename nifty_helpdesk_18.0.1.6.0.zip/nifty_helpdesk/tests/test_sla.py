from datetime import datetime, timedelta

from odoo import fields
from odoo.tests import TransactionCase, tagged

from .common import create_always_open_calendar, setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestSla(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        cls.calendar = create_always_open_calendar(cls.env)
        cls.stage_hold = cls.env['helpdesk.stage'].create({'name': 'Hold', 'sequence': 1})
        cls.stage_working = cls.env['helpdesk.stage'].create({'name': 'Working', 'sequence': 1})
        cls.stage_open.sequence = 0
        cls.stage_hold.sequence = 3  # before the target stage, so it can pause
        cls.stage_working.sequence = 5
        cls.stage_closed.sequence = 10
        cls.team.stage_ids = [(4, cls.stage_hold.id), (4, cls.stage_working.id)]
        cls.tag_vip = cls.env['helpdesk.tag'].create({'name': 'VIP'})
        cls.company_partner = cls.env['res.partner'].create({'name': 'Big Co', 'is_company': True})
        cls.employee_partner = cls.env['res.partner'].create({'name': 'Big Co Person', 'parent_id': cls.company_partner.id})
        cls.sla = cls.env['helpdesk.sla'].create({
            'name': 'Urgent in 4h',
            'team_id': cls.team.id,
            'priority': '3',
            'stage_id': cls.stage_working.id,
            'exclude_stage_ids': [(6, 0, cls.stage_hold.ids)],
            'time': 4,
            'resource_calendar_id': cls.calendar.id,
        })

    def _ticket(self, **values):
        return self.env['helpdesk.ticket'].create({'name': 'SLA ticket', 'team_id': self.team.id, **values})

    def test_matching_by_priority(self):
        self.assertFalse(self._ticket(priority='0').sla_status_ids)
        ticket = self._ticket(priority='3')
        self.assertEqual(ticket.sla_status_ids.sla_id, self.sla)
        self.assertAlmostEqual(
            ticket.sla_status_ids.deadline, ticket.create_date + timedelta(hours=4), delta=timedelta(seconds=1),
        )
        self.assertEqual(ticket.sla_deadline, ticket.sla_status_ids.deadline)

    def test_priority_change_adds_and_removes_running_status(self):
        ticket = self._ticket(priority='0')
        ticket.priority = '3'
        self.assertEqual(ticket.sla_status_ids.sla_id, self.sla)
        ticket.priority = '1'
        self.assertFalse(ticket.sla_status_ids)

    def test_matching_by_tags_and_customer(self):
        self.sla.write({'tag_ids': [(6, 0, self.tag_vip.ids)], 'partner_ids': [(6, 0, self.company_partner.ids)]})
        self.assertFalse(self._ticket(priority='3', tag_ids=[(6, 0, self.tag_vip.ids)]).sla_status_ids)
        self.assertFalse(self._ticket(priority='3', partner_id=self.employee_partner.id).sla_status_ids)
        ticket = self._ticket(priority='3', partner_id=self.employee_partner.id, tag_ids=[(6, 0, self.tag_vip.ids)])
        self.assertTrue(ticket.sla_status_ids, "A contact of a listed company should match")

    def test_team_without_sla_gets_none(self):
        self.team.use_sla = False
        self.assertFalse(self._ticket(priority='3').sla_status_ids)

    def test_reaching_target_or_later_stage_meets_sla(self):
        ticket = self._ticket(priority='3')
        ticket.stage_id = self.stage_closed  # later than the target stage
        status = ticket.sla_status_ids
        self.assertEqual(status.status, 'reached')
        self.assertTrue(status.reached_datetime)
        self.assertFalse(ticket.sla_failed)
        self.assertFalse(ticket.sla_deadline)

    def test_cron_marks_overdue_as_failed_and_it_stays_failed(self):
        ticket = self._ticket(priority='3')
        status = ticket.sla_status_ids
        status.deadline = fields.Datetime.now() - timedelta(minutes=5)
        self.env['helpdesk.sla.status']._cron_mark_failed()
        self.assertEqual(status.status, 'failed')
        self.assertTrue(ticket.sla_failed)
        ticket.stage_id = self.stage_working
        self.assertEqual(status.status, 'failed')
        self.assertTrue(status.reached_datetime)

    def test_reaching_after_deadline_fails(self):
        ticket = self._ticket(priority='3')
        ticket.sla_status_ids.deadline = fields.Datetime.now() - timedelta(minutes=1)
        ticket.stage_id = self.stage_working
        self.assertEqual(ticket.sla_status_ids.status, 'failed')

    def test_excluded_stage_pauses_and_extends_deadline(self):
        ticket = self._ticket(priority='3')
        status = ticket.sla_status_ids
        original_deadline = status.deadline
        ticket.stage_id = self.stage_hold
        self.assertTrue(status.paused_since)
        self.assertFalse(ticket.sla_deadline, 'A paused SLA has no running deadline')
        # Pretend the ticket waited two hours on hold.
        status.paused_since = fields.Datetime.now() - timedelta(hours=2)
        ticket.stage_id = self.stage_open
        self.assertFalse(status.paused_since)
        self.assertAlmostEqual(status.deadline, original_deadline + timedelta(hours=2), delta=timedelta(seconds=5))

    def test_paused_sla_is_not_failed_by_cron(self):
        ticket = self._ticket(priority='3')
        ticket.stage_id = self.stage_hold
        ticket.sla_status_ids.deadline = fields.Datetime.now() - timedelta(hours=1)
        self.env['helpdesk.sla.status']._cron_mark_failed()
        self.assertEqual(ticket.sla_status_ids.status, 'ongoing')

    def test_deadline_skips_non_working_hours(self):
        office = self.env['resource.calendar'].create({
            'name': 'Office 9-17',
            'tz': 'UTC',
            'attendance_ids': [(5, 0, 0)] + [
                (0, 0, {'name': f'Day {day}', 'dayofweek': str(day), 'hour_from': 9, 'hour_to': 17,
                        'day_period': 'morning'})
                for day in range(5)
            ],
        })
        self.sla.resource_calendar_id = office
        friday_4pm = datetime(2026, 11, 6, 16, 0)
        # One hour on Friday, then three hours from Monday 9:00.
        self.assertEqual(self.sla._compute_deadline(friday_4pm), datetime(2026, 11, 9, 12, 0))

    def test_status_display_and_color(self):
        status = self._ticket(priority='3').sla_status_ids
        self.assertEqual(status.display_name, 'Urgent in 4h')
        self.assertEqual(status.color, 0)
        status.ticket_id.stage_id = self.stage_working
        self.assertEqual(status.color, 10)
