from odoo.exceptions import AccessError
from odoo.tests import TransactionCase, new_test_user, tagged
from odoo.tools import mute_logger

from .common import setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestSalesLinks(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        cls.company = cls.env['res.partner'].create({'name': 'Sales Customer Co', 'is_company': True})
        cls.contact = cls.env['res.partner'].create({'name': 'Sales Contact', 'parent_id': cls.company.id})
        cls.product = cls.env['product.product'].create({'name': 'Support visit', 'type': 'service', 'list_price': 100})
        cls.order = cls.env['sale.order'].create({
            'partner_id': cls.company.id,
            'order_line': [(0, 0, {'product_id': cls.product.id, 'product_uom_qty': 1})],
        })
        cls.sales_user = new_test_user(
            cls.env, login='hd_sales_user',
            groups='nifty_helpdesk.group_helpdesk_user,sales_team.group_sale_salesman',
        )

    def test_quotation_link_is_optional_and_stored(self):
        ticket = self.env['helpdesk.ticket'].create({
            'name': 'Linked', 'team_id': self.team.id, 'partner_id': self.contact.id,
        })
        self.assertFalse(ticket.sale_order_id)
        ticket.sale_order_id = self.order
        self.assertEqual(ticket.sale_order_id, self.order)
        self.assertEqual(ticket.commercial_partner_id, self.company)

    def test_sales_user_can_link_order(self):
        self.team.member_ids = [(4, self.sales_user.id)]
        ticket = self.env['helpdesk.ticket'].with_user(self.sales_user).create({
            'name': 'By sales user', 'team_id': self.team.id, 'partner_id': self.contact.id,
            'sale_order_id': self.order.id,
        })
        self.assertEqual(ticket.sale_order_id, self.order)

    @mute_logger('odoo.models', 'odoo.addons.base.models.ir_model')
    def test_helpdesk_only_user_cannot_read_sales_links(self):
        ticket = self.env['helpdesk.ticket'].create({
            'name': 'Hidden link', 'team_id': self.team.id, 'sale_order_id': self.order.id,
        })
        fields_seen = self.env['helpdesk.ticket'].with_user(self.user_a).fields_get()
        self.assertNotIn('sale_order_id', fields_seen)
        self.assertNotIn('invoice_id', fields_seen)
        with self.assertRaises(AccessError):
            ticket.with_user(self.user_a).read(['sale_order_id'])
        # The rest of the ticket stays readable.
        self.assertEqual(ticket.with_user(self.user_a).read(['name'])[0]['name'], 'Hidden link')

    def test_invoice_link(self):
        journal = self.env['account.journal'].search([('type', '=', 'sale'), ('company_id', '=', self.env.company.id)], limit=1)
        if not journal:
            self.skipTest('No sales journal: the database has no chart of accounts')
        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.company.id,
            'journal_id': journal.id,
            'invoice_line_ids': [(0, 0, {'product_id': self.product.id, 'quantity': 1, 'price_unit': 100})],
        })
        ticket = self.env['helpdesk.ticket'].create({
            'name': 'Invoiced', 'team_id': self.team.id, 'partner_id': self.contact.id, 'invoice_id': invoice.id,
        })
        self.assertEqual(ticket.invoice_id, invoice)
