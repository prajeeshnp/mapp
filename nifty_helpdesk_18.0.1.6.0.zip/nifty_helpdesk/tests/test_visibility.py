from odoo.tests import TransactionCase, new_test_user, tagged
from odoo.tools import mute_logger

from .common import setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestVisibility(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        cls.outsider = new_test_user(cls.env, login='hd_vis_outsider', groups='nifty_helpdesk.group_helpdesk_user')
        cls.portal_user = new_test_user(cls.env, login='hd_vis_portal', groups='base.group_portal')
        cls.ticket = cls.env['helpdesk.ticket'].create({
            'name': 'Visibility ticket',
            'team_id': cls.team.id,
            'partner_id': cls.portal_user.partner_id.id,
        })

    def _visible_to(self, user):
        return bool(self.env['helpdesk.ticket'].with_user(user).search([('id', '=', self.ticket.id)]))

    def test_invited_only_members_and_followers(self):
        self.team.visibility = 'invited'
        self.assertTrue(self._visible_to(self.user_a))
        self.assertFalse(self._visible_to(self.outsider))
        self.ticket.message_subscribe(partner_ids=self.outsider.partner_id.ids)
        self.assertTrue(self._visible_to(self.outsider))
        self.assertFalse(self._visible_to(self.portal_user))

    def test_internal_shows_to_all_helpdesk_users(self):
        self.team.visibility = 'internal'
        self.assertTrue(self._visible_to(self.outsider))
        self.assertFalse(self._visible_to(self.portal_user))
        self.assertTrue(self.env['helpdesk.team'].with_user(self.outsider).search([('id', '=', self.team.id)]))

    def test_portal_shows_to_customer(self):
        self.team.visibility = 'portal'
        self.assertTrue(self._visible_to(self.outsider))
        self.assertTrue(self._visible_to(self.portal_user))

    def test_portal_follower_sees_ticket(self):
        self.team.visibility = 'portal'
        other_portal = new_test_user(self.env, login='hd_vis_portal_2', groups='base.group_portal')
        self.assertFalse(bool(self.env['helpdesk.ticket'].with_user(other_portal).search([('id', '=', self.ticket.id)])))
        self.ticket.message_subscribe(partner_ids=other_portal.partner_id.ids)
        self.assertTrue(bool(self.env['helpdesk.ticket'].with_user(other_portal).search([('id', '=', self.ticket.id)])))

    def test_leaving_portal_removes_portal_followers(self):
        self.team.visibility = 'portal'
        other_portal = new_test_user(self.env, login='hd_vis_portal_3', groups='base.group_portal')
        self.team.message_subscribe(partner_ids=other_portal.partner_id.ids)
        self.ticket.message_subscribe(partner_ids=other_portal.partner_id.ids)
        self.team.visibility = 'internal'
        self.assertNotIn(other_portal.partner_id, self.team.message_partner_ids)
        self.assertNotIn(other_portal.partner_id, self.ticket.message_partner_ids)
        self.assertNotIn(self.portal_user.partner_id, self.ticket.message_partner_ids)

    def test_team_followers_follow_new_tickets(self):
        self.team.message_subscribe(partner_ids=self.outsider.partner_id.ids)
        ticket = self.env['helpdesk.ticket'].create({'name': 'Followed', 'team_id': self.team.id})
        self.assertIn(self.outsider.partner_id, ticket.message_partner_ids)
        self.assertTrue(bool(self.env['helpdesk.ticket'].with_user(self.outsider).search([('id', '=', ticket.id)])))

    def test_customer_following_team_is_not_copied_onto_tickets(self):
        self.team.visibility = 'portal'
        follower = new_test_user(self.env, login='hd_vis_portal_4', groups='base.group_portal')
        self.team.message_subscribe(partner_ids=follower.partner_id.ids)
        ticket = self.env['helpdesk.ticket'].create({'name': 'Not for you', 'team_id': self.team.id})
        self.assertNotIn(follower.partner_id, ticket.message_partner_ids)

    @mute_logger('odoo.addons.base.models.ir_rule')
    def test_sla_status_follows_ticket_visibility(self):
        self.team.visibility = 'invited'
        stage_target = self.stage_closed
        self.env['helpdesk.sla'].create({
            'name': 'Visible SLA', 'team_id': self.team.id, 'priority': '0',
            'stage_id': stage_target.id, 'time': 8,
        })
        ticket = self.env['helpdesk.ticket'].create({'name': 'With SLA', 'team_id': self.team.id})
        self.assertTrue(ticket.sla_status_ids)
        Status = self.env['helpdesk.sla.status']
        self.assertFalse(Status.with_user(self.outsider).search([('ticket_id', '=', ticket.id)]))
        self.assertTrue(Status.with_user(self.user_a).search([('ticket_id', '=', ticket.id)]))
