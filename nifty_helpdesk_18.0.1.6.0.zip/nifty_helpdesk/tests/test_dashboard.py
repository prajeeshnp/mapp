from datetime import datetime

from odoo.tests import TransactionCase, new_test_user, tagged

from .common import setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestDashboard(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        cls.team.visibility = 'invited'
        cls.repair = cls.env['helpdesk.job.type'].create({'name': 'Dash Repair'})
        cls.install = cls.env['helpdesk.job.type'].create({'name': 'Dash Install'})
        Ticket = cls.env['helpdesk.ticket']

        def ticket(name, created, **values):
            record = Ticket.create({'name': name, 'team_id': cls.team.id, **values})
            # create_date is set by the ORM; move it into the reporting period.
            cls.env.cr.execute('UPDATE helpdesk_ticket SET create_date = %s WHERE id = %s', (created, record.id))
            return record

        cls.t_jan_resolved = ticket('Jan fixed', datetime(2026, 1, 10, 9), job_type_id=cls.repair.id,
                                    user_ids=[(6, 0, cls.user_a.ids)])
        cls.t_jan_open = ticket('Jan open', datetime(2026, 1, 20, 9), job_type_id=cls.repair.id,
                                user_ids=[(6, 0, cls.user_b.ids)])
        cls.t_mar_unassigned = ticket('Mar waiting', datetime(2026, 3, 5, 9), job_type_id=cls.install.id,
                                      priority='3')
        cls.t_mar_shared = ticket('Mar shared', datetime(2026, 3, 6, 9),
                                  user_ids=[(6, 0, (cls.user_a | cls.user_b).ids)])
        cls.t_outside = ticket('Last year', datetime(2025, 6, 1, 9), job_type_id=cls.repair.id)
        (cls.t_jan_resolved | cls.t_mar_shared).write({'stage_id': cls.stage_closed.id})
        cls.env.invalidate_all()

    def _data(self, user=None, **filters):
        Ticket = self.env['helpdesk.ticket'].with_context(tz='UTC')
        if user:
            Ticket = Ticket.with_user(user)
        base = {'date_from': '2026-01-01', 'date_to': '2026-12-31', 'team_id': self.team.id}
        return Ticket.get_dashboard_data({**base, **filters})

    def test_kpis_and_status(self):
        data = self._data()
        kpis = data['kpis']
        self.assertEqual(kpis['total'], 4, 'Tickets outside the period are excluded')
        self.assertEqual(kpis['resolved'], 2)
        self.assertEqual(kpis['open'], 2)
        self.assertEqual(kpis['unassigned'], 1)
        self.assertEqual(kpis['resolution_rate'], 50)
        self.assertEqual({row['key']: row['count'] for row in data['status']},
                         {'resolved': 2, 'in_progress': 1, 'unassigned': 1})

    def test_by_job_type_includes_tickets_without_type(self):
        rows = {row['name']: row for row in self._data()['by_job_type']}
        self.assertEqual((rows['Dash Repair']['resolved'], rows['Dash Repair']['in_progress']), (1, 1))
        self.assertEqual(rows['Dash Install']['unassigned'], 1)
        self.assertEqual(rows['No job type']['resolved'], 1)
        self.assertEqual(rows['No job type']['domain'], [('job_type_id', '=', False)])

    def test_months_cover_the_whole_period(self):
        months = self._data(date_to='2026-04-30')['by_month']
        self.assertEqual([m['key'] for m in months], ['2026-01', '2026-02', '2026-03', '2026-04'])
        by_key = {m['key']: m for m in months}
        self.assertEqual((by_key['2026-01']['resolved'], by_key['2026-01']['unresolved']), (1, 1))
        self.assertEqual((by_key['2026-02']['resolved'], by_key['2026-02']['unresolved']), (0, 0))
        self.assertEqual((by_key['2026-03']['resolved'], by_key['2026-03']['unresolved']), (1, 1))

    def test_engineers_count_shared_tickets_for_each(self):
        rows = {row['name']: row['count'] for row in self._data()['by_engineer']}
        self.assertEqual(rows, {self.user_a.name: 2, self.user_b.name: 1})

    def test_filters(self):
        self.assertEqual(self._data(job_type_id=self.repair.id)['kpis']['total'], 2)
        self.assertEqual(self._data(user_id=self.user_b.id)['kpis']['total'], 2)
        self.assertEqual(self._data(priority='3')['kpis']['total'], 1)
        self.assertEqual(self._data(date_from='2026-03-01')['kpis']['total'], 2)

    def test_drill_down_domains_match_the_counts(self):
        data = self._data()
        Ticket = self.env['helpdesk.ticket']
        for row in data['status']:
            found = Ticket.search_count(data['domain'] + data['status_domains'][row['key']])
            self.assertEqual(found, row['count'], row['key'])
        march = next(m for m in data['by_month'] if m['key'] == '2026-03')
        self.assertEqual(Ticket.search(data['domain'] + march['domain']), self.t_mar_unassigned | self.t_mar_shared)

    def test_period_uses_user_time_zone(self):
        # Created 2026-01-10 09:00 UTC; in Tokyo that is still 10 January.
        Ticket = self.env['helpdesk.ticket'].with_context(tz='Asia/Tokyo')
        domain = Ticket._dashboard_domain({'date_from': '2026-01-10', 'date_to': '2026-01-10'})
        self.assertIn(('create_date', '>=', '2026-01-09 15:00:00'), domain)
        self.assertIn(('create_date', '<', '2026-01-10 15:00:00'), domain)

    def test_respects_ticket_visibility(self):
        outsider = new_test_user(self.env, login='hd_dash_outsider', groups='nifty_helpdesk.group_helpdesk_user')
        self.assertEqual(self._data(user=outsider)['kpis']['total'], 0)
        self.assertEqual(self._data(user=self.user_a)['kpis']['total'], 4)
