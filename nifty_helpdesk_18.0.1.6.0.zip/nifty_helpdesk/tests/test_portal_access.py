from odoo.exceptions import AccessError
from odoo.tests import HttpCase, TransactionCase, new_test_user, tagged
from odoo.tools import mute_logger

from .common import setup_helpdesk_data


def setup_portal_data(cls):
    setup_helpdesk_data(cls, visibility='portal')
    cls.portal_user = new_test_user(cls.env, login='hd_portal', groups='base.group_portal')
    cls.other_portal_user = new_test_user(cls.env, login='hd_portal_other', groups='base.group_portal')
    Ticket = cls.env['helpdesk.ticket']
    cls.own_ticket = Ticket.create({
        'name': 'My own ticket',
        'team_id': cls.team.id,
        'partner_id': cls.portal_user.partner_id.id,
    })
    cls.other_ticket = Ticket.create({
        'name': 'Someone else ticket',
        'team_id': cls.team.id,
        'partner_id': cls.other_portal_user.partner_id.id,
    })


@tagged('post_install', '-at_install')
class TestAccessRules(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_portal_data(cls)

    def test_portal_user_reads_only_own_tickets(self):
        tickets = self.env['helpdesk.ticket'].with_user(self.portal_user).search([])
        self.assertEqual(tickets, self.own_ticket)
        self.assertEqual(self.own_ticket.with_user(self.portal_user).name, 'My own ticket')

    @mute_logger('odoo.addons.base.models.ir_rule', 'odoo.models')
    def test_portal_user_cannot_read_other_ticket(self):
        with self.assertRaises(AccessError):
            self.other_ticket.with_user(self.portal_user).read(['name'])

    @mute_logger('odoo.addons.base.models.ir_rule', 'odoo.models')
    def test_portal_user_cannot_write_or_create(self):
        with self.assertRaises(AccessError):
            self.own_ticket.with_user(self.portal_user).write({'name': 'Changed'})
        with self.assertRaises(AccessError):
            self.other_ticket.with_user(self.portal_user).write({'name': 'Changed'})
        with self.assertRaises(AccessError):
            self.env['helpdesk.ticket'].with_user(self.portal_user).create({
                'name': 'New',
                'team_id': self.team.id,
            })

    def test_portal_user_can_reply_on_own_ticket(self):
        message = self.own_ticket.with_user(self.portal_user).message_post(
            body='Any update?', message_type='comment', subtype_xmlid='mail.mt_comment',
        )
        self.assertEqual(message.author_id, self.portal_user.partner_id)

    @mute_logger('odoo.addons.base.models.ir_rule', 'odoo.models')
    def test_portal_user_cannot_reply_on_other_ticket(self):
        with self.assertRaises(AccessError):
            self.other_ticket.with_user(self.portal_user).message_post(
                body='Sneaky', message_type='comment', subtype_xmlid='mail.mt_comment',
            )

    @mute_logger('odoo.addons.base.models.ir_rule', 'odoo.models')
    def test_helpdesk_user_sees_only_own_team_tickets(self):
        self.team.visibility = 'invited'
        outsider = new_test_user(self.env, login='hd_outsider', groups='nifty_helpdesk.group_helpdesk_user')
        Ticket = self.env['helpdesk.ticket']
        self.assertFalse(Ticket.with_user(outsider).search([('id', '=', self.own_ticket.id)]))
        self.assertTrue(Ticket.with_user(self.user_a).search([('id', '=', self.own_ticket.id)]))
        self.assertFalse(self.env['helpdesk.team'].with_user(outsider).search([('id', '=', self.team.id)]))

    def test_helpdesk_manager_sees_all_tickets(self):
        manager = new_test_user(self.env, login='hd_manager', groups='nifty_helpdesk.group_helpdesk_manager')
        tickets = self.env['helpdesk.ticket'].with_user(manager).search([('team_id', '=', self.team.id)])
        self.assertEqual(tickets, self.own_ticket | self.other_ticket)


@tagged('post_install', '-at_install')
class TestPortalPages(HttpCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_portal_data(cls)

    def setUp(self):
        super().setUp()
        self.authenticate('hd_portal', 'hd_portal')

    def test_list_shows_only_own_tickets(self):
        response = self.url_open('/my/tickets')
        self.assertEqual(response.status_code, 200)
        self.assertIn('My own ticket', response.text)
        self.assertNotIn('Someone else ticket', response.text)

    def test_detail_page_renders_with_chatter(self):
        response = self.url_open(self.own_ticket.access_url)
        self.assertEqual(response.status_code, 200)
        self.assertIn('My own ticket', response.text)
        self.assertIn('o_portal_chatter', response.text)

    def test_detail_page_of_other_ticket_redirects(self):
        response = self.url_open(self.other_ticket.access_url)
        self.assertNotIn('Someone else ticket', response.text)

    def test_home_counter(self):
        result = self.make_jsonrpc_request('/my/counters', {'counters': ['ticket_count']})
        self.assertEqual(result['ticket_count'], 1)
