from odoo.tests import tagged

from odoo.addons.mail.tests.common import MailCommon

from .common import setup_helpdesk_data

RAW_EMAIL = """Return-Path: <{email_from}>
To: {to}
From: {email_from}
Subject: {subject}
Message-ID: <{message_id}@example.com>
MIME-Version: 1.0
Content-Type: text/plain; charset="utf-8"

My printer is on fire.
"""


@tagged('post_install', '-at_install')
class TestMailGateway(MailCommon):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        cls.team.alias_name = 'test-helpdesk'
        cls.alias_email = f'test-helpdesk@{cls.alias_domain}'

    def _process_email(self, email_from, subject, message_id):
        raw_email = RAW_EMAIL.format(
            to=self.alias_email, email_from=email_from, subject=subject, message_id=message_id,
        )
        with self.mock_mail_gateway():
            thread_id = self.env['mail.thread'].message_process(None, raw_email)
        return self.env['helpdesk.ticket'].browse(thread_id)

    def test_alias_targets_ticket_and_team(self):
        self.assertEqual(self.team.alias_id.alias_model_id.model, 'helpdesk.ticket')
        self.assertIn(f"'team_id': {self.team.id}", self.team.alias_defaults)

    def test_email_from_unknown_sender_creates_ticket(self):
        ticket = self._process_email('stranger@example.com', 'Help please', 'unknown-sender')
        self.assertTrue(ticket.exists())
        self.assertEqual(ticket.name, 'Help please')
        self.assertEqual(ticket.team_id, self.team)
        self.assertEqual(ticket.email, 'stranger@example.com')
        self.assertFalse(ticket.partner_id)
        self.assertRegex(ticket.ref, r'^HD/\d{5}$')
        self.assertIn('printer is on fire', ticket.description)

    def test_email_from_known_partner_links_and_subscribes_partner(self):
        partner = self.env['res.partner'].create({'name': 'Known', 'email': 'known@example.com'})
        ticket = self._process_email('known@example.com', 'Known sender', 'known-sender')
        self.assertEqual(ticket.partner_id, partner)
        self.assertIn(partner, ticket.message_partner_ids)

    def test_email_runs_auto_assignment(self):
        self.team.assignment_method = 'round_robin'
        ticket = self._process_email('stranger@example.com', 'Assign me', 'assign-me')
        self.assertIn(ticket.user_ids, self.team.member_ids)
