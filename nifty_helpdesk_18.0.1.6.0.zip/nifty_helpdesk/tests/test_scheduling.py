from datetime import datetime, timedelta

from freezegun import freeze_time

from odoo import fields
from odoo.tests import TransactionCase, tagged

from odoo.addons.mail.tests.common import MailCommon

from .common import setup_helpdesk_data


@tagged('post_install', '-at_install')
class TestMultipleAssignees(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        cls.team.visibility = 'invited'

    def test_several_engineers_are_followers_and_can_see_ticket(self):
        outsider_team = self.env['helpdesk.team'].create({
            'name': 'Other', 'stage_ids': [(6, 0, self.stage_open.ids)],
        })
        ticket = self.env['helpdesk.ticket'].create({
            'name': 'Shared job', 'team_id': outsider_team.id,
            'user_ids': [(6, 0, (self.user_a | self.user_b).ids)],
        })
        self.assertEqual(ticket.user_ids, self.user_a | self.user_b)
        self.assertLessEqual((self.user_a | self.user_b).partner_id, ticket.message_partner_ids)
        for user in self.user_a | self.user_b:
            self.assertTrue(self.env['helpdesk.ticket'].with_user(user).search([('id', '=', ticket.id)]))

    def test_adding_an_engineer_later_subscribes_them(self):
        ticket = self.env['helpdesk.ticket'].create({'name': 'Grow', 'team_id': self.team.id})
        ticket.user_ids = [(4, self.user_b.id)]
        self.assertIn(self.user_b.partner_id, ticket.message_partner_ids)

    def test_auto_assignment_skipped_when_engineers_set(self):
        self.team.assignment_method = 'round_robin'
        ticket = self.env['helpdesk.ticket'].create({
            'name': 'Manual', 'team_id': self.team.id, 'user_ids': [(6, 0, self.user_b.ids)],
        })
        self.assertEqual(ticket.user_ids, self.user_b)
        self.assertFalse(self.team.last_assigned_user_id)

    def test_balanced_counts_shared_tickets_for_each_engineer(self):
        self.team.assignment_method = 'balanced'
        self.env['helpdesk.ticket'].create({
            'name': 'Shared', 'team_id': self.team.id, 'user_ids': [(6, 0, (self.user_a | self.user_b).ids)],
        })
        self.env['helpdesk.ticket'].create({
            'name': 'Only A', 'team_id': self.team.id, 'user_ids': [(6, 0, self.user_a.ids)],
        })
        ticket = self.env['helpdesk.ticket'].create({'name': 'Next', 'team_id': self.team.id})
        self.assertEqual(ticket.user_ids, self.user_b)

    def test_my_tickets_filter_matches_any_assignee(self):
        ticket = self.env['helpdesk.ticket'].create({
            'name': 'Mine too', 'team_id': self.team.id, 'user_ids': [(6, 0, (self.user_a | self.user_b).ids)],
        })
        for user in self.user_a | self.user_b:
            found = self.env['helpdesk.ticket'].with_user(user).search([('user_ids', 'in', user.id)])
            self.assertIn(ticket, found)

    def test_ticket_analysis_groups_by_each_assignee(self):
        ticket = self.env['helpdesk.ticket'].create({
            'name': 'Shared report', 'team_id': self.team.id,
            'user_ids': [(6, 0, (self.user_a | self.user_b).ids)],
        })
        self.env.flush_all()
        groups = dict(self.env['helpdesk.ticket.analysis']._read_group(
            [('ticket_id', '=', ticket.id)], ['user_ids'], ['__count'],
        ))
        self.assertEqual(groups, {self.user_a: 1, self.user_b: 1})


@tagged('post_install', '-at_install')
class TestSchedulingAndFields(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)
        cls.job_type = cls.env['helpdesk.job.type'].create({'name': 'Installation'})
        cls.project = cls.env['project.project'].create({'name': 'Helpdesk Test Project'})

    def test_optional_project_and_job_type(self):
        ticket = self.env['helpdesk.ticket'].create({'name': 'Plain', 'team_id': self.team.id})
        self.assertFalse(ticket.project_id)
        ticket.write({'project_id': self.project.id, 'job_type_id': self.job_type.id})
        self.assertEqual(ticket.project_id, self.project)
        self.assertEqual(ticket.job_type_id, self.job_type)
        self.assertTrue(
            self.env['helpdesk.ticket'].with_user(self.user_a).search([('job_type_id', '=', self.job_type.id)])
        )

    @freeze_time('2026-11-07 20:00:00')
    def test_today_range_follows_user_timezone(self):
        # 20:00 UTC on 7 Nov is already 8 Nov 01:30 in Kolkata.
        self.user_a.tz = 'Asia/Kolkata'
        Ticket = self.env['helpdesk.ticket'].with_user(self.user_a).with_context(tz=None)
        start, end = Ticket._today_utc_range()
        self.assertEqual(start, datetime(2026, 11, 7, 18, 30))
        self.assertEqual(end, datetime(2026, 11, 8, 18, 30))
        # The browser's time zone wins, as it does for displayed times:
        # 20:00 UTC is still 7 Nov in New York.
        start, _end = Ticket.with_context(tz='America/New_York')._today_utc_range()
        self.assertEqual(start, datetime(2026, 11, 7, 5, 0))

    def test_overview_lists_tickets_scheduled_today(self):
        start, end = self.env['helpdesk.ticket']._today_utc_range()
        Ticket = self.env['helpdesk.ticket']
        today = Ticket.create({
            'name': 'Visit today', 'team_id': self.team.id, 'scheduled_date': start + timedelta(hours=10),
            'user_ids': [(6, 0, self.user_a.ids)],
        })
        Ticket.create({'name': 'Visit tomorrow', 'team_id': self.team.id, 'scheduled_date': end + timedelta(hours=1)})
        Ticket.create({
            'name': 'Closed today', 'team_id': self.team.id, 'scheduled_date': start + timedelta(hours=11),
            'stage_id': self.stage_closed.id,
        })
        self.team.invalidate_recordset()
        self.assertEqual(self.team.today_ticket_count, 1)
        summary = str(self.team.today_ticket_summary)
        self.assertIn(today.display_name, summary)
        self.assertIn(self.user_a.name, summary)
        self.assertNotIn('Visit tomorrow', summary)
        self.assertNotIn('Closed today', summary)

    def test_no_schedule_means_empty_summary(self):
        self.assertEqual(self.team.today_ticket_count, 0)
        self.assertFalse(self.team.today_ticket_summary)


@tagged('post_install', '-at_install')
class TestSchedulingTracking(MailCommon):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        setup_helpdesk_data(cls)

    def test_scheduled_date_is_tracked(self):
        ticket = self.env['helpdesk.ticket'].create({'name': 'Track', 'team_id': self.team.id})
        self.flush_tracking()
        ticket.scheduled_date = fields.Datetime.now()
        self.flush_tracking()
        tracked = ticket.message_ids.tracking_value_ids.field_id.mapped('name')
        self.assertIn('scheduled_date', tracked)
