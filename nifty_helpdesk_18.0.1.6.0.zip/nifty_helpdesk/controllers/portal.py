from datetime import timedelta

from werkzeug.exceptions import NotFound

from odoo import _, fields, http
from odoo.exceptions import AccessError, MissingError
from odoo.http import request

from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager


class HelpdeskCustomerPortal(CustomerPortal):

    def _ticket_domain(self):
        partner = request.env.user.partner_id
        return ['|', ('partner_id', '=', partner.id), ('message_partner_ids', 'in', partner.ids)]

    def _prepare_home_portal_values(self, counters):
        values = super()._prepare_home_portal_values(counters)
        if 'ticket_count' in counters:
            Ticket = request.env['helpdesk.ticket']
            values['ticket_count'] = (
                Ticket.search_count(self._ticket_domain()) if Ticket.has_access('read') else 0
            )
        return values

    def _ticket_sortings(self):
        return {
            'date': {'label': _('Newest'), 'order': 'create_date desc, id desc'},
            'name': {'label': _('Subject'), 'order': 'name, id desc'},
            'priority': {'label': _('Priority'), 'order': 'priority desc, id desc'},
        }

    @http.route(['/my/tickets', '/my/tickets/page/<int:page>'], type='http', auth='user', website=True)
    def portal_my_tickets(self, page=1, sortby='date', **kw):
        Ticket = request.env['helpdesk.ticket']
        if not Ticket.has_access('read'):
            return request.redirect('/my')

        sortings = self._ticket_sortings()
        if sortby not in sortings:
            sortby = 'date'
        domain = self._ticket_domain()
        pager = portal_pager(
            url='/my/tickets',
            url_args={'sortby': sortby},
            total=Ticket.search_count(domain),
            page=page,
            step=self._items_per_page,
        )
        tickets = Ticket.search(
            domain,
            order=sortings[sortby]['order'],
            limit=self._items_per_page,
            offset=pager['offset'],
        )
        request.session['my_tickets_history'] = tickets.ids[:100]

        values = self._prepare_portal_layout_values()
        values.update({
            'tickets': tickets.sudo(),  # stages are not readable by portal users
            'page_name': 'ticket',
            'default_url': '/my/tickets',
            'pager': pager,
            'searchbar_sortings': sortings,
            'sortby': sortby,
        })
        return request.render('nifty_helpdesk.portal_my_tickets', values)

    @http.route('/my/tickets/<int:ticket_id>', type='http', auth='public', website=True)
    def portal_my_ticket(self, ticket_id, access_token=None, **kw):
        try:
            ticket_sudo = self._document_check_access('helpdesk.ticket', ticket_id, access_token)
        except (AccessError, MissingError):
            return request.redirect('/my')

        values = self._prepare_portal_layout_values()
        values.update({
            'ticket': ticket_sudo,
            'page_name': 'ticket',
        })
        values = self._get_page_view_values(
            ticket_sudo, access_token, values, 'my_tickets_history', False, **kw
        )
        return request.render('nifty_helpdesk.portal_my_ticket', values)

    @http.route('/my/tickets/<int:ticket_id>/close', type='http', auth='public', methods=['POST'], website=True)
    def portal_close_ticket(self, ticket_id, access_token=None, **kw):
        try:
            ticket_sudo = self._document_check_access('helpdesk.ticket', ticket_id, access_token)
        except (AccessError, MissingError):
            return request.redirect('/my')
        user = request.env.user
        author = ticket_sudo.partner_id if user._is_public() else user.partner_id
        ticket_sudo._close_by_customer(author)
        return request.redirect(ticket_sudo.get_portal_url())


class HelpdeskRatingPage(http.Controller):

    @http.route('/helpdesk/rating/<int:team_id>', type='http', auth='public', website=True)
    def team_ratings(self, team_id, **kw):
        team = request.env['helpdesk.team'].sudo().browse(team_id).exists()
        if not team or not (team.active and team.rating_public and team.use_rating and team.visibility == 'portal'):
            raise NotFound()
        since = fields.Datetime.now() - timedelta(days=30)
        counts = dict(request.env['rating.rating'].sudo()._read_group(
            [
                ('parent_res_model', '=', 'helpdesk.team'),
                ('parent_res_id', '=', team.id),
                ('consumed', '=', True),
                ('rating', '>=', 1),
                ('write_date', '>=', since),
            ],
            ['rating_text'],
            ['__count'],
        ))
        total = sum(counts.values())
        stats = [
            {'label': label, 'count': counts.get(key, 0),
             'image': f'/rating/static/src/img/rating_{value}.png',
             'percent': round(100.0 * counts.get(key, 0) / total) if total else 0}
            for key, value, label in (
                ('top', 5, _('Satisfied')), ('ok', 3, _('Okay')), ('ko', 1, _('Dissatisfied')),
            )
        ]
        return request.render('nifty_helpdesk.team_rating_page', {
            'team': team,
            'stats': stats,
            'total': total,
        })
