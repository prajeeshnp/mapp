from markupsafe import Markup

from odoo import _, api, fields, models
from odoo.exceptions import UserError


class HelpdeskTicketMerge(models.TransientModel):
    _name = 'helpdesk.ticket.merge'
    _description = 'Merge Helpdesk Tickets'

    ticket_ids = fields.Many2many('helpdesk.ticket', string='Tickets', required=True)
    target_ticket_id = fields.Many2one(
        'helpdesk.ticket', string='Merge Into', required=True,
        domain="[('id', 'in', ticket_ids)]",
    )

    @api.model
    def default_get(self, fields_list):
        values = super().default_get(fields_list)
        if self.env.context.get('active_model') == 'helpdesk.ticket':
            tickets = self.env['helpdesk.ticket'].browse(self.env.context.get('active_ids', []))
            values['ticket_ids'] = [(6, 0, tickets.ids)]
            values['target_ticket_id'] = tickets.sorted(lambda t: (t.create_date, t.id))[:1].id
        return values

    def action_merge(self):
        self.ensure_one()
        target = self.target_ticket_id
        others = self.ticket_ids - target
        if not others:
            raise UserError(_('Select at least two tickets to merge.'))
        if target not in self.ticket_ids:
            raise UserError(_('The ticket to merge into must be one of the selected tickets.'))
        self.ticket_ids.check_access('write')

        target_sudo = target.sudo()
        description_parts = [target.description or '']
        for ticket in others.sudo():
            if ticket.description:
                description_parts.append(
                    Markup('<h4>%s</h4>%s') % (_('From %s', ticket.display_name), ticket.description)
                )
            target_sudo.message_subscribe(partner_ids=ticket.message_partner_ids.ids)
            self._move_records(ticket, target)

        target_sudo.write({
            'description': Markup('<br/>').join(Markup(part) for part in description_parts if part),
            'tag_ids': [(4, tag.id) for tag in others.tag_ids],
        })
        target.message_post(
            body=Markup('%s %s') % (_('Merged tickets:'), ', '.join(others.mapped('display_name'))),
            subtype_xmlid='mail.mt_note',
        )
        for ticket in others:
            ticket.message_post(
                body=Markup('%s <a href="#" data-oe-model="helpdesk.ticket" data-oe-id="%s">%s</a>') % (
                    _('Merged into'), target.id, target.display_name,
                ),
                subtype_xmlid='mail.mt_note',
            )
        others.action_archive()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'helpdesk.ticket',
            'res_id': target.id,
            'view_mode': 'form',
        }

    def _move_records(self, source, target):
        """Re-point the conversation, attachments, activities and ratings."""
        moves = {
            'mail.message': ('model', 'res_id'),
            'ir.attachment': ('res_model', 'res_id'),
            'mail.activity': ('res_model', 'res_id'),
            'rating.rating': ('res_model', 'res_id'),
        }
        for model_name, (model_field, id_field) in moves.items():
            records = self.env[model_name].sudo().search([
                (model_field, '=', 'helpdesk.ticket'),
                (id_field, '=', source.id),
            ])
            records.write({id_field: target.id})
