import base64
import io
from datetime import datetime, time, timedelta

import pytz
import xlsxwriter

from odoo import _, api, fields, models
from odoo.exceptions import UserError


class HelpdeskEngineerReport(models.TransientModel):
    _name = 'helpdesk.engineer.report'
    _description = 'Tickets per Engineer'

    def _default_user_ids(self):
        if self.env.user.has_group('nifty_helpdesk.group_helpdesk_manager'):
            return self.env['res.users']
        return self.env.user

    def _default_date_from(self):
        return fields.Date.context_today(self).replace(day=1)

    user_ids = fields.Many2many(
        'res.users', string='Engineers', default=_default_user_ids,
        domain=lambda self: [('groups_id', 'in', self.env.ref('nifty_helpdesk.group_helpdesk_user').ids),
                             ('share', '=', False)],
        help='Leave empty for every engineer.',
    )
    date_from = fields.Date(string='From', required=True, default=_default_date_from)
    date_to = fields.Date(string='To', required=True, default=fields.Date.context_today)
    team_ids = fields.Many2many('helpdesk.team', string='Teams', help='Leave empty for every team.')
    include_closed = fields.Boolean(string='Include Closed Tickets', default=True)

    @api.constrains('date_from', 'date_to')
    def _check_dates(self):
        if any(report.date_from > report.date_to for report in self):
            raise UserError(_('The From date must be on or before the To date.'))

    # ------------------------------------------------------------
    # Data
    # ------------------------------------------------------------

    def _utc_bounds(self):
        """The From and To days, in the user's time zone, as naive UTC datetimes."""
        self.ensure_one()
        tz = pytz.timezone(self.env.context.get('tz') or self.env.user.tz or 'UTC')

        def to_utc(day):
            return tz.localize(datetime.combine(day, time.min)).astimezone(pytz.utc).replace(tzinfo=None)

        return to_utc(self.date_from), to_utc(self.date_to + timedelta(days=1))

    def _ticket_domain(self):
        self.ensure_one()
        start, end = self._utc_bounds()
        domain = [('scheduled_date', '>=', start), ('scheduled_date', '<', end), ('user_ids', '!=', False)]
        if self.user_ids:
            domain.append(('user_ids', 'in', self.user_ids.ids))
        if self.team_ids:
            domain.append(('team_id', 'in', self.team_ids.ids))
        if not self.include_closed:
            domain.append(('stage_id.is_closed', '=', False))
        return domain

    def _get_tickets(self):
        return self.env['helpdesk.ticket'].search(self._ticket_domain(), order='scheduled_date, id')

    def _get_groups(self):
        """[(engineer, tickets)] sorted by engineer name. A ticket shared by
        several engineers is listed under each of them."""
        self.ensure_one()
        tickets = self._get_tickets()
        by_user = {}
        for ticket in tickets:
            for user in ticket.user_ids:
                if self.user_ids and user not in self.user_ids:
                    continue
                by_user.setdefault(user, self.env['helpdesk.ticket'])
                by_user[user] |= ticket
        return sorted(by_user.items(), key=lambda item: (item[0].name or '').lower())

    def _get_report_data(self):
        """Groups with worked hours: [{'engineer', 'lines': [{'ticket', 'hours'}],
        'hours'}]. 'hours' on a line is that engineer's own time on the ticket;
        the ticket's total_hours covers every engineer."""
        self.ensure_one()
        groups = self._get_groups()
        tickets = self.env['helpdesk.ticket'].union(*[group_tickets for _user, group_tickets in groups])
        hours = tickets._hours_by_engineer()
        result = []
        for user, group_tickets in groups:
            lines = [{'ticket': ticket, 'hours': hours[ticket.id].get(user, 0.0)} for ticket in group_tickets]
            result.append({'engineer': user, 'lines': lines, 'hours': sum(line['hours'] for line in lines)})
        return result

    @staticmethod
    def _format_hours(value):
        hours, minutes = divmod(round((value or 0.0) * 60), 60)
        return f'{hours}:{minutes:02d}'

    def _local(self, value):
        return fields.Datetime.context_timestamp(self, value) if value else False

    # ------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------

    def _worklog_domain(self):
        """Work sessions on the report's tickets, by the chosen engineers."""
        self.ensure_one()
        domain = [('ticket_id', 'in', self._get_tickets().ids)]
        if self.user_ids:
            domain.append(('user_id', 'in', self.user_ids.ids))
        return domain

    def action_view(self):
        """Each engineer's own hours, one group per engineer, then per ticket."""
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id('nifty_helpdesk.action_helpdesk_worklog')
        action.update({
            'display_name': _('Engineer Hours %(start)s – %(end)s', start=self.date_from, end=self.date_to),
            'domain': self._worklog_domain(),
            'context': {'search_default_group_user': 1, 'search_default_group_ticket': 1, 'create': False},
        })
        return action

    def action_view_tickets(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id('nifty_helpdesk.action_helpdesk_ticket')
        action.update({
            'display_name': _('Engineer Tickets %(start)s – %(end)s', start=self.date_from, end=self.date_to),
            'domain': self._ticket_domain(),
            'view_mode': 'list,form,calendar',
            'views': [(False, 'list'), (False, 'form'), (False, 'calendar')],
            'context': {'search_default_group_user': 1},
        })
        return action

    def action_print(self):
        self.ensure_one()
        if not self._get_groups():
            raise UserError(_('No assigned tickets are scheduled in this period.'))
        return self.env.ref('nifty_helpdesk.action_report_engineer_tickets').report_action(self)

    def action_export_xlsx(self):
        self.ensure_one()
        groups = self._get_report_data()
        if not groups:
            raise UserError(_('No assigned tickets are scheduled in this period.'))
        filename = f'engineer_tickets_{self.date_from}_{self.date_to}.xlsx'
        attachment = self.env['ir.attachment'].create({
            'name': filename,
            'datas': base64.b64encode(self._build_xlsx(groups)),
            'res_model': self._name,
            'res_id': self.id,
            'mimetype': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        })
        return {
            'type': 'ir.actions.act_url',
            'url': f'/web/content/{attachment.id}?download=true',
            'target': 'self',
        }

    def _build_xlsx(self, groups):
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet(_('Engineer Tickets'))
        bold = workbook.add_format({'bold': True})
        header = workbook.add_format({'bold': True, 'bg_color': '#E9ECEF', 'border': 1})
        when = workbook.add_format({'num_format': 'yyyy-mm-dd hh:mm'})
        # Excel stores durations as fractions of a day; [h]:mm shows totals over 24h.
        duration = workbook.add_format({'num_format': '[h]:mm'})
        duration_bold = workbook.add_format({'num_format': '[h]:mm', 'bold': True, 'top': 1})
        subtotal = workbook.add_format({'bold': True, 'top': 1})

        sheet.write(0, 0, _('Tickets per engineer'), bold)
        sheet.write(1, 0, _('From %(start)s to %(end)s (scheduled date)', start=self.date_from, end=self.date_to))
        columns = [
            (_('Engineer'), 22), (_('Scheduled For'), 18), (_('Reference'), 12), (_('Subject'), 40),
            (_('Customer'), 24), (_('Team'), 18), (_('Job Type'), 16), (_('Project'), 20),
            (_('Stage'), 14), (_('Priority'), 10), (_('Other Engineers'), 28),
            (_('Engineer Hours'), 14), (_('Ticket Total Hours'), 16),
        ]
        for col, (title, width) in enumerate(columns):
            sheet.write(3, col, title, header)
            sheet.set_column(col, col, width)

        priorities = dict(self.env['helpdesk.ticket']._fields['priority'].selection)
        row = 4
        hours_col = len(columns) - 2
        for group in groups:
            user = group['engineer']
            for line in group['lines']:
                ticket = line['ticket']
                local = self._local(ticket.scheduled_date)
                values = [
                    user.name,
                    local.replace(tzinfo=None) if local else '',
                    ticket.ref,
                    ticket.name,
                    ticket.partner_id.display_name or '',
                    ticket.team_id.name or '',
                    ticket.job_type_id.name or '',
                    ticket.project_id.name or '',
                    ticket.stage_id.name or '',
                    priorities.get(ticket.priority, ''),
                    ', '.join((ticket.user_ids - user).mapped('name')),
                ]
                for col, value in enumerate(values):
                    if col == 1 and value:
                        sheet.write_datetime(row, col, value, when)
                    else:
                        sheet.write(row, col, value)
                sheet.write_number(row, hours_col, line['hours'] / 24.0, duration)
                sheet.write_number(row, hours_col + 1, ticket.total_hours / 24.0, duration)
                row += 1
            sheet.write(row, 0, _('Total %s', user.name), subtotal)
            sheet.write_number(row, hours_col, group['hours'] / 24.0, duration_bold)
            row += 1
        sheet.autofilter(3, 0, max(row - 1, 3), len(columns) - 1)
        sheet.freeze_panes(4, 0)
        workbook.close()
        return output.getvalue()
