from odoo import fields, models, tools

from ..models.helpdesk_ticket import PRIORITIES


class HelpdeskSlaAnalysis(models.Model):
    _name = 'helpdesk.sla.analysis'
    _description = 'Helpdesk SLA Analysis'
    _auto = False
    _order = 'create_date desc'

    ticket_id = fields.Many2one('helpdesk.ticket', readonly=True)
    sla_id = fields.Many2one('helpdesk.sla', string='SLA Policy', readonly=True)
    team_id = fields.Many2one('helpdesk.team', readonly=True)
    partner_id = fields.Many2one('res.partner', string='Customer', readonly=True)
    priority = fields.Selection(PRIORITIES, readonly=True)
    status = fields.Selection(
        [('ongoing', 'In Progress'), ('reached', 'Met'), ('failed', 'Failed')], readonly=True,
    )
    create_date = fields.Datetime(string='Ticket Created On', readonly=True)
    deadline = fields.Datetime(readonly=True)
    reached_datetime = fields.Datetime(string='Reached On', readonly=True)
    hours_to_reach = fields.Float(string='Working Hours to Reach', readonly=True, aggregator='avg')
    failed_count = fields.Integer(string='Failed SLAs', readonly=True)

    def init(self):
        tools.drop_view_if_exists(self.env.cr, self._table)
        self.env.cr.execute(f"""
            CREATE OR REPLACE VIEW {self._table} AS (
                SELECT
                    st.id,
                    st.ticket_id,
                    st.sla_id,
                    t.team_id,
                    t.partner_id,
                    t.priority,
                    st.status,
                    t.create_date,
                    st.deadline,
                    st.reached_datetime,
                    CASE WHEN st.reached_datetime IS NULL THEN NULL ELSE st.hours_to_reach END AS hours_to_reach,
                    CASE WHEN st.status = 'failed' THEN 1 ELSE 0 END AS failed_count
                FROM helpdesk_sla_status st
                JOIN helpdesk_ticket t ON t.id = st.ticket_id
                WHERE t.active
            )
        """)
