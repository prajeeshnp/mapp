from odoo import fields, models, tools

from ..models.helpdesk_ticket import PRIORITIES


class HelpdeskTicketAnalysis(models.Model):
    _name = 'helpdesk.ticket.analysis'
    _description = 'Helpdesk Ticket Analysis'
    _auto = False
    _order = 'create_date desc'

    ticket_id = fields.Many2one('helpdesk.ticket', readonly=True)
    team_id = fields.Many2one('helpdesk.team', readonly=True)
    # The view's id is the ticket id, so the ticket's assignee table can be reused.
    user_ids = fields.Many2many(
        'res.users', relation='helpdesk_ticket_user_rel', column1='ticket_id', column2='user_id',
        string='Assigned To', readonly=True,
    )
    project_id = fields.Many2one('project.project', readonly=True)
    job_type_id = fields.Many2one('helpdesk.job.type', readonly=True)
    stage_id = fields.Many2one('helpdesk.stage', readonly=True)
    partner_id = fields.Many2one('res.partner', string='Customer', readonly=True)
    priority = fields.Selection(PRIORITIES, readonly=True)
    is_closed = fields.Boolean(string='Closed', readonly=True)
    sla_failed = fields.Boolean(string='SLA Failed', readonly=True)
    create_date = fields.Datetime(string='Created On', readonly=True)
    close_date = fields.Datetime(string='Closed On', readonly=True)
    open_hours = fields.Float(string='Hours Open', readonly=True, aggregator='avg')
    assign_hours = fields.Float(string='Working Hours to Assign', readonly=True, aggregator='avg')
    close_hours = fields.Float(string='Working Hours to Close', readonly=True, aggregator='avg')
    first_response_hours = fields.Float(string='Working Hours to First Reply', readonly=True, aggregator='avg')
    rating = fields.Float(string='Rating (/5)', readonly=True, aggregator='avg')
    total_hours = fields.Float(string='Time Spent', readonly=True, aggregator='sum')

    def init(self):
        tools.drop_view_if_exists(self.env.cr, self._table)
        # NULL instead of 0 for events that have not happened yet, so averages
        # only cover tickets where they did.
        self.env.cr.execute(f"""
            CREATE OR REPLACE VIEW {self._table} AS (
                SELECT
                    t.id,
                    t.id AS ticket_id,
                    t.team_id,
                    t.project_id,
                    t.job_type_id,
                    t.stage_id,
                    t.partner_id,
                    t.priority,
                    COALESCE(s.is_closed, FALSE) AS is_closed,
                    COALESCE(t.sla_failed, FALSE) AS sla_failed,
                    t.create_date,
                    t.close_date,
                    EXTRACT(EPOCH FROM (
                        COALESCE(t.close_date, NOW() AT TIME ZONE 'UTC') - t.create_date
                    )) / 3600.0 AS open_hours,
                    CASE WHEN t.assign_date IS NULL THEN NULL ELSE t.assign_hours END AS assign_hours,
                    CASE WHEN t.close_date IS NULL THEN NULL ELSE t.close_hours END AS close_hours,
                    CASE WHEN t.first_response_date IS NULL THEN NULL ELSE t.first_response_hours END
                        AS first_response_hours,
                    NULLIF(t.rating_last_value, 0) AS rating,
                    COALESCE(t.total_hours, 0) AS total_hours
                FROM helpdesk_ticket t
                LEFT JOIN helpdesk_stage s ON s.id = t.stage_id
                WHERE t.active
            )
        """)
