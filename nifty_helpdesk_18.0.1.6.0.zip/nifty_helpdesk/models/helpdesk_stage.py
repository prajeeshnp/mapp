from odoo import fields, models


class HelpdeskStage(models.Model):
    _name = 'helpdesk.stage'
    _description = 'Helpdesk Stage'
    _order = 'sequence, id'

    name = fields.Char(required=True, translate=True)
    sequence = fields.Integer(default=10)
    fold = fields.Boolean(string='Folded in Kanban')
    is_closed = fields.Boolean(
        string='Closing Stage',
        help='Tickets in this stage count as closed and get a close date.',
    )
    team_ids = fields.Many2many(
        'helpdesk.team',
        'helpdesk_team_stage_rel',
        'stage_id',
        'team_id',
        string='Teams',
    )
    mail_template_id = fields.Many2one(
        'mail.template',
        string='Email Template',
        domain=[('model', '=', 'helpdesk.ticket')],
        help='Sent to the customer when a ticket reaches this stage.',
    )
    rating_template_id = fields.Many2one(
        'mail.template',
        string='Rating Request Template',
        domain=[('model', '=', 'helpdesk.ticket')],
        help='Asks the customer for a rating when a ticket reaches this stage. '
             'Only sent for teams with customer ratings turned on.',
    )
