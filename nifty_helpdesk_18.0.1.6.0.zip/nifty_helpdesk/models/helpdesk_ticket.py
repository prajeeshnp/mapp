from datetime import datetime, time, timedelta

import pytz

from odoo import _, api, fields, models

PRIORITIES = [('0', 'Low'), ('1', 'Medium'), ('2', 'High'), ('3', 'Urgent')]

# Changing any of these can change which SLA policies apply to a ticket.
SLA_TRIGGER_FIELDS = {'team_id', 'priority', 'tag_ids', 'partner_id'}


class HelpdeskTicket(models.Model):
    _name = 'helpdesk.ticket'
    _description = 'Helpdesk Ticket'
    # rating.mixin extends mail.thread, so it must be listed before it.
    _inherit = ['portal.mixin', 'rating.mixin', 'mail.thread', 'mail.activity.mixin']
    _order = 'priority desc, id desc'
    _rec_names_search = ['ref', 'name']
    # Portal users only have read access, and replying must not require write.
    _mail_post_access = 'read'

    def _default_team_id(self):
        Team = self.env['helpdesk.team']
        return Team.search([('member_ids', 'in', self.env.uid)], limit=1) or Team.search([], limit=1)

    ref = fields.Char(string='Reference', readonly=True, copy=False, index=True, default='New')
    name = fields.Char(string='Subject', required=True, tracking=True)
    active = fields.Boolean(default=True)
    description = fields.Html()
    partner_id = fields.Many2one('res.partner', string='Customer', tracking=True, index=True)
    email = fields.Char(compute='_compute_email', store=True, readonly=False)
    team_id = fields.Many2one(
        'helpdesk.team',
        string='Team',
        required=True,
        tracking=True,
        index=True,
        ondelete='restrict',
        default=_default_team_id,
    )
    assignable_user_ids = fields.Many2many('res.users', compute='_compute_assignable_user_ids')
    user_ids = fields.Many2many(
        'res.users',
        relation='helpdesk_ticket_user_rel',
        column1='ticket_id',
        column2='user_id',
        string='Assigned To',
        tracking=True,
        context={'active_test': False},
        domain="[('id', 'in', assignable_user_ids)]",
    )
    priority = fields.Selection(PRIORITIES, default='0', required=True, tracking=True)
    tag_ids = fields.Many2many('helpdesk.tag', string='Tags')
    project_id = fields.Many2one('project.project', string='Project', tracking=True, index=True)
    commercial_partner_id = fields.Many2one(related='partner_id.commercial_partner_id')
    # Only users who can read sales documents see these links.
    sale_order_id = fields.Many2one(
        'sale.order',
        string='Quotation / Sales Order',
        tracking=True,
        index='btree_not_null',
        domain="[('partner_id', 'child_of', commercial_partner_id)] if commercial_partner_id else []",
        groups='sales_team.group_sale_salesman,account.group_account_invoice,account.group_account_readonly',
    )
    invoice_id = fields.Many2one(
        'account.move',
        string='Invoice',
        tracking=True,
        index='btree_not_null',
        domain="[('move_type', 'in', ('out_invoice', 'out_refund')), ('state', '!=', 'cancel')]"
               " + ([('partner_id', 'child_of', commercial_partner_id)] if commercial_partner_id else [])",
        groups='account.group_account_invoice,account.group_account_readonly',
    )
    job_type_id = fields.Many2one('helpdesk.job.type', string='Job Type', tracking=True, index=True)
    scheduled_date = fields.Datetime(string='Scheduled For', tracking=True, index=True, copy=False)
    worklog_ids = fields.One2many('helpdesk.ticket.worklog', 'ticket_id', string='Work Sessions', copy=False)
    total_hours = fields.Float(
        string='Time Spent', compute='_compute_total_hours', store=True, aggregator='sum',
        help='Total of all work sessions, by every engineer.',
    )
    stage_id = fields.Many2one(
        'helpdesk.stage',
        string='Stage',
        compute='_compute_stage_id',
        store=True,
        readonly=False,
        tracking=True,
        index=True,
        copy=False,
        ondelete='restrict',
        group_expand='_read_group_stage_ids',
        domain="[('team_ids', 'in', team_id)]",
    )
    is_closed = fields.Boolean(related='stage_id.is_closed', string='Closed')
    kanban_state = fields.Selection(
        [('normal', 'In Progress'), ('done', 'Ready'), ('blocked', 'Blocked')],
        string='Kanban State',
        compute='_compute_kanban_state',
        store=True,
        readonly=False,
        copy=False,
    )
    close_date = fields.Datetime(compute='_compute_close_date', store=True, copy=False)
    can_customer_close = fields.Boolean(compute='_compute_can_customer_close')

    # Activity and response times, in working hours of the team's calendar
    last_activity_date = fields.Datetime(
        default=fields.Datetime.now,
        readonly=True,
        copy=False,
        help='Last stage change or customer-visible message. Used to close inactive tickets.',
    )
    assign_date = fields.Datetime(compute='_compute_assign_date', store=True, copy=False)
    first_response_date = fields.Datetime(readonly=True, copy=False)
    assign_hours = fields.Float(
        string='Working Hours to Assign', compute='_compute_working_hours', store=True, aggregator='avg',
    )
    close_hours = fields.Float(
        string='Working Hours to Close', compute='_compute_working_hours', store=True, aggregator='avg',
    )
    first_response_hours = fields.Float(
        string='Working Hours to First Reply', compute='_compute_working_hours', store=True, aggregator='avg',
    )

    # SLA
    sla_status_ids = fields.One2many('helpdesk.sla.status', 'ticket_id', string='SLA Status')
    sla_deadline = fields.Datetime(
        string='SLA Deadline', compute='_compute_sla_summary', store=True, index=True,
        help='Earliest deadline among the SLA policies still running on this ticket.',
    )
    sla_failed = fields.Boolean(string='SLA Failed', compute='_compute_sla_summary', store=True)

    @api.depends('team_id')
    def _compute_stage_id(self):
        for ticket in self:
            stages = ticket.team_id.stage_ids
            if ticket.stage_id not in stages:
                ticket.stage_id = stages[:1]

    @api.depends('worklog_ids.duration')
    def _compute_total_hours(self):
        for ticket in self:
            ticket.total_hours = sum(ticket.worklog_ids.mapped('duration'))

    def _hours_by_engineer(self):
        """{ticket id: {user: hours}} from the work sessions, read with the
        current user's rights."""
        result = {ticket.id: {} for ticket in self}
        groups = self.env['helpdesk.ticket.worklog']._read_group(
            [('ticket_id', 'in', self.ids)], ['ticket_id', 'user_id'], ['duration:sum'],
        )
        for ticket, user, hours in groups:
            result[ticket.id][user] = hours or 0.0
        return result

    def action_view_worklogs(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Work Sessions · %s', self.display_name),
            'res_model': 'helpdesk.ticket.worklog',
            'view_mode': 'list,pivot',
            'domain': [('ticket_id', '=', self.id)],
            'context': {'default_ticket_id': self.id, 'search_default_group_user': 1},
        }

    @api.depends('team_id')
    def _compute_assignable_user_ids(self):
        for ticket in self:
            ticket.assignable_user_ids = (
                ticket.team_id._get_assignable_users() if ticket.team_id else self.env['res.users']
            )

    @api.depends('stage_id')
    def _compute_kanban_state(self):
        self.kanban_state = 'normal'

    @api.depends('stage_id')
    def _compute_close_date(self):
        for ticket in self:
            if not ticket.stage_id.is_closed:
                ticket.close_date = False
            elif not ticket.close_date:
                ticket.close_date = fields.Datetime.now()

    @api.depends('user_ids')
    def _compute_assign_date(self):
        for ticket in self:
            if ticket.user_ids and not ticket.assign_date:
                ticket.assign_date = fields.Datetime.now()

    @api.depends('create_date', 'assign_date', 'close_date', 'first_response_date')
    def _compute_working_hours(self):
        for ticket in self:
            calendar = ticket.team_id._get_calendar() if ticket.team_id else False
            start = ticket.create_date
            for date_field, hours_field in (
                ('assign_date', 'assign_hours'),
                ('close_date', 'close_hours'),
                ('first_response_date', 'first_response_hours'),
            ):
                end = ticket[date_field]
                if calendar and start and end and end > start:
                    ticket[hours_field] = calendar.get_work_hours_count(start, end, compute_leaves=True)
                else:
                    ticket[hours_field] = 0.0

    @api.depends('sla_status_ids.deadline', 'sla_status_ids.status', 'sla_status_ids.paused_since')
    def _compute_sla_summary(self):
        for ticket in self:
            running = ticket.sla_status_ids.filtered(
                lambda status: status.status == 'ongoing' and status.deadline and not status.paused_since
            )
            ticket.sla_deadline = min(running.mapped('deadline')) if running else False
            ticket.sla_failed = any(status.status == 'failed' for status in ticket.sla_status_ids)

    @api.depends('partner_id')
    def _compute_email(self):
        for ticket in self:
            if ticket.partner_id.email:
                ticket.email = ticket.partner_id.email

    @api.depends('team_id.allow_customer_close', 'team_id.closing_stage_id', 'stage_id.is_closed')
    def _compute_can_customer_close(self):
        for ticket in self:
            team = ticket.team_id
            ticket.can_customer_close = bool(
                team.allow_customer_close and team.closing_stage_id and not ticket.stage_id.is_closed
            )

    @api.depends('ref', 'name')
    def _compute_display_name(self):
        for ticket in self:
            ticket.display_name = f'{ticket.ref} {ticket.name}' if ticket.ref else ticket.name

    def _compute_access_url(self):
        super()._compute_access_url()
        for ticket in self:
            ticket.access_url = f'/my/tickets/{ticket.id}'

    @api.model
    def _read_group_stage_ids(self, stages, domain):
        team_id = self.env.context.get('default_team_id')
        team_domain = [('team_ids', 'in', team_id)] if team_id else [('team_ids', '!=', False)]
        return stages | stages.search(team_domain)

    # ------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------

    @api.model_create_multi
    def create(self, vals_list):
        Sequence = self.env['ir.sequence'].sudo()
        default_team_id = None
        for vals in vals_list:
            vals['ref'] = Sequence.next_by_code('helpdesk.ticket')
            # Pass the first stage explicitly: Odoo only sends a stage's email on
            # creation when the stage is part of the create values.
            if not vals.get('stage_id'):
                team_id = vals.get('team_id')
                if not team_id:
                    if default_team_id is None:
                        default_team_id = self.default_get(['team_id']).get('team_id') or False
                    team_id = default_team_id
                if team_id:
                    vals['stage_id'] = self.env['helpdesk.team'].browse(team_id).stage_ids[:1].id
        tickets = super().create(vals_list)
        # Assign one by one so each balanced pick sees the previous assignment.
        # Automatic assignment only applies when nobody was assigned by hand.
        for ticket in tickets:
            if not ticket.user_ids:
                assignee = ticket.team_id._get_next_assignee()
                if assignee:
                    ticket.user_ids = assignee
            if ticket.partner_id:
                ticket.message_subscribe(partner_ids=ticket.partner_id.ids)
        tickets._subscribe_new_assignees({})
        tickets._sla_apply()
        return tickets

    def write(self, vals):
        if 'stage_id' in vals:
            vals = dict(vals, last_activity_date=fields.Datetime.now())
        previous_users = {ticket.id: ticket.user_ids for ticket in self} if 'user_ids' in vals else None
        result = super().write(vals)
        if previous_users is not None:
            self._subscribe_new_assignees(previous_users)
        if vals.get('partner_id'):
            for ticket in self:
                ticket.message_subscribe(partner_ids=ticket.partner_id.ids)
        if SLA_TRIGGER_FIELDS & vals.keys():
            self._sla_apply()
        if 'stage_id' in vals:
            self._sla_on_stage_change()
            self._send_rating_requests()
        return result

    # ------------------------------------------------------------
    # Mail
    # ------------------------------------------------------------

    def _creation_subtype(self):
        return self.env.ref('nifty_helpdesk.mt_ticket_new')

    def _subscribe_new_assignees(self, previous_users):
        """Make newly assigned engineers followers, so they keep access on
        invited-only teams, and tell them about it."""
        Users = self.env['res.users']
        for ticket in self:
            added = (ticket.user_ids - previous_users.get(ticket.id, Users)).filtered('active')
            if not added:
                continue
            ticket.message_subscribe(partner_ids=added.partner_id.ids)
            to_notify = added - self.env.user
            if to_notify and not self.env.context.get('mail_auto_subscribe_no_notify'):
                ticket._message_auto_subscribe_notify(
                    to_notify.partner_id.ids, 'nifty_helpdesk.message_ticket_assigned',
                )

    def _track_template(self, changes):
        result = super()._track_template(changes)
        ticket = self[0]
        template = ticket.stage_id.mail_template_id
        # Without a customer or an email address the email would go nowhere.
        if 'stage_id' in changes and template and (ticket.partner_id or ticket.email):
            result['stage_id'] = (template, {
                'auto_delete_keep_log': False,
                'subtype_id': self.env['ir.model.data']._xmlid_to_res_id('mail.mt_note'),
                'email_layout_xmlid': 'mail.mail_notification_light',
            })
        return result

    def _message_auto_subscribe(self, updated_values, followers_existing_policy='skip'):
        result = super()._message_auto_subscribe(updated_values, followers_existing_policy)
        if updated_values.get('team_id'):
            # Customers can follow a team for its news, but must not be copied
            # onto every new ticket: that would show them other customers' tickets.
            team = self.env['helpdesk.team'].browse(updated_values['team_id'])
            customer_followers = team.message_partner_ids.filtered('partner_share')
            for ticket in self:
                to_remove = (ticket.message_partner_ids & customer_followers) - ticket.partner_id
                if to_remove:
                    ticket.message_unsubscribe(partner_ids=to_remove.ids)
        return result

    def _message_post_after_hook(self, message, msg_values):
        result = super()._message_post_after_hook(message, msg_values)
        is_visible_to_customer = (
            message.message_type in ('comment', 'email')
            and not message.is_internal
            and not message.subtype_id.internal
        )
        if is_visible_to_customer:
            values = {'last_activity_date': fields.Datetime.now()}
            author_is_agent = message.author_id.user_ids.filtered(lambda user: not user.share)
            if author_is_agent and not self.first_response_date:
                values['first_response_date'] = fields.Datetime.now()
            self.sudo().write(values)
        return result

    @api.model
    def message_new(self, msg_dict, custom_values=None):
        values = dict(custom_values or {})
        if msg_dict.get('author_id'):
            values.setdefault('partner_id', msg_dict['author_id'])
        if msg_dict.get('body'):
            values.setdefault('description', msg_dict['body'])
        return super().message_new(msg_dict, custom_values=values)

    # ------------------------------------------------------------
    # Ratings
    # ------------------------------------------------------------

    def _rating_get_parent_field_name(self):
        return 'team_id'

    def _rating_get_operator(self):
        # The rating is credited to the first engineer on the ticket.
        return self.user_ids[:1].partner_id

    # ------------------------------------------------------------
    # Scheduling
    # ------------------------------------------------------------

    @api.model
    def _today_utc_range(self):
        """Start and end of today, as naive UTC datetimes. Uses the same time
        zone as displayed times: the browser's, else the user's preference."""
        tz = pytz.timezone(self.env.context.get('tz') or self.env.user.tz or 'UTC')
        local_start = datetime.combine(datetime.now(pytz.utc).astimezone(tz).date(), time.min)
        start = tz.localize(local_start).astimezone(pytz.utc).replace(tzinfo=None)
        return start, start + timedelta(days=1)

    @api.model
    def _scheduled_today_domain(self):
        start, end = self._today_utc_range()
        return [('scheduled_date', '>=', start), ('scheduled_date', '<', end)]

    def _send_rating_requests(self):
        for ticket in self:
            template = ticket.stage_id.rating_template_id
            if template and ticket.team_id.use_rating and ticket.partner_id:
                ticket.rating_send_request(template, force_send=False)

    # ------------------------------------------------------------
    # Closing
    # ------------------------------------------------------------

    def _close_by_customer(self, author):
        """Close the ticket on behalf of the customer. Expects a sudo-ed record
        whose access was already checked by the portal controller."""
        self.ensure_one()
        if not self.can_customer_close:
            return False
        self.write({'stage_id': self.team_id.closing_stage_id.id})
        self.message_post(
            body=_('The customer closed this ticket.'),
            author_id=author.id,
            message_type='comment',
            subtype_xmlid='mail.mt_note',
        )
        return True

    # ------------------------------------------------------------
    # SLA
    # ------------------------------------------------------------

    def _sla_apply(self):
        """Add statuses for SLA policies that now match and drop running ones
        that no longer do. Statuses already met or failed are kept."""
        Status = self.env['helpdesk.sla.status'].sudo()
        now = fields.Datetime.now()
        for ticket in self.sudo():
            statuses = ticket.sla_status_ids
            matching = self.env['helpdesk.sla'].sudo()
            if ticket.team_id.use_sla:
                matching = ticket.team_id.sla_ids.filtered(lambda sla: sla._matches(ticket))
            dropped = statuses.filtered(
                lambda status: status.status == 'ongoing' and status.sla_id not in matching
            )
            kept = statuses - dropped
            dropped.unlink()
            new_slas = matching - kept.sla_id
            if new_slas:
                Status.create([sla._prepare_status_values(ticket, now) for sla in new_slas])

    def _sla_on_stage_change(self):
        now = fields.Datetime.now()
        for ticket in self.sudo():
            for status in ticket.sla_status_ids.filtered(lambda status: not status.reached_datetime):
                status._on_ticket_stage(ticket.stage_id, now)
