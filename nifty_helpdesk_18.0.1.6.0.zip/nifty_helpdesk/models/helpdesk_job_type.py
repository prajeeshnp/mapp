from odoo import fields, models


class HelpdeskJobType(models.Model):
    _name = 'helpdesk.job.type'
    _description = 'Helpdesk Job Type'
    _order = 'sequence, name, id'

    name = fields.Char(required=True, translate=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    description = fields.Text()

    _sql_constraints = [
        ('name_uniq', 'unique (name)', 'A job type with this name already exists.'),
    ]
