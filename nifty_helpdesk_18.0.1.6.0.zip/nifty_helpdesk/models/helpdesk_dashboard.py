from datetime import date, datetime, time, timedelta

import pytz
from dateutil.relativedelta import relativedelta

from odoo import _, api, fields, models

ENGINEER_LIMIT = 10


class HelpdeskTicket(models.Model):
    _inherit = 'helpdesk.ticket'

    # ------------------------------------------------------------
    # Dashboard
    # ------------------------------------------------------------

    @api.model
    def _dashboard_utc(self, day):
        """Midnight of ``day`` in the user's time zone, as a UTC string."""
        tz = pytz.timezone(self.env.context.get('tz') or self.env.user.tz or 'UTC')
        moment = tz.localize(datetime.combine(day, time.min)).astimezone(pytz.utc).replace(tzinfo=None)
        return fields.Datetime.to_string(moment)

    @api.model
    def _dashboard_domain(self, filters):
        """Tickets created in the period (in the user's time zone) that match
        the dashboard filters. Record rules still apply on top of this."""
        to_utc = self._dashboard_utc
        date_from = fields.Date.to_date(filters.get('date_from'))
        date_to = fields.Date.to_date(filters.get('date_to'))
        domain = []
        if date_from:
            domain.append(('create_date', '>=', to_utc(date_from)))
        if date_to:
            domain.append(('create_date', '<', to_utc(date_to + timedelta(days=1))))
        for key, field_name in (('team_id', 'team_id'), ('job_type_id', 'job_type_id')):
            value = filters.get(key)
            if value:
                domain.append((field_name, '=', int(value)))
        if filters.get('user_id'):
            domain.append(('user_ids', 'in', [int(filters['user_id'])]))
        if filters.get('priority') not in (None, '', False):
            domain.append(('priority', '=', str(filters['priority'])))
        return domain

    @api.model
    def _dashboard_status_domains(self):
        return {
            'resolved': [('stage_id.is_closed', '=', True)],
            'in_progress': [('stage_id.is_closed', '=', False), ('user_ids', '!=', False)],
            'unassigned': [('stage_id.is_closed', '=', False), ('user_ids', '=', False)],
        }

    @api.model
    def get_dashboard_data(self, filters=None):
        filters = filters or {}
        domain = self._dashboard_domain(filters)
        status_domains = self._dashboard_status_domains()

        def count(extra=()):
            return self.search_count(domain + list(extra))

        def avg(field_name, extra=()):
            [(value,)] = self._read_group(domain + list(extra), [], [f'{field_name}:avg'])
            return round(value or 0.0, 2)

        status_counts = {key: count(extra) for key, extra in status_domains.items()}
        total = sum(status_counts.values())
        kpis = {
            'total': total,
            'resolved': status_counts['resolved'],
            'open': status_counts['in_progress'] + status_counts['unassigned'],
            'unassigned': status_counts['unassigned'],
            'sla_failed': count([('sla_failed', '=', True)]),
            'avg_close_hours': avg('close_hours', [('close_date', '!=', False)]),
            'avg_first_response_hours': avg('first_response_hours', [('first_response_date', '!=', False)]),
            'resolution_rate': round(100.0 * status_counts['resolved'] / total) if total else 0,
        }

        return {
            'domain': domain,
            'status_domains': status_domains,
            'kpis': kpis,
            'status': [
                {'key': key, 'label': label, 'count': status_counts[key]}
                for key, label in (
                    ('resolved', _('Resolved')),
                    ('in_progress', _('In progress')),
                    ('unassigned', _('Unassigned')),
                )
            ],
            'by_job_type': self._dashboard_by_job_type(domain, status_domains),
            'by_month': self._dashboard_by_month(domain, filters),
            'by_engineer': self._dashboard_by_engineer(domain),
            'options': self._dashboard_options(),
        }

    def _dashboard_by_job_type(self, domain, status_domains):
        no_type = _('No job type')
        rows = {}

        def row_for(job_type):
            key = job_type.id or False
            if key not in rows:
                rows[key] = {
                    'id': key, 'name': job_type.name if job_type else no_type,
                    'domain': [('job_type_id', '=', key)],
                    'resolved': 0, 'in_progress': 0, 'unassigned': 0, 'avg_close_hours': 0.0,
                }
            return rows[key]

        for status, extra in status_domains.items():
            for job_type, number in self._read_group(domain + extra, ['job_type_id'], ['__count']):
                row_for(job_type)[status] = number
        closed = [('close_date', '!=', False)]
        for job_type, hours in self._read_group(domain + closed, ['job_type_id'], ['close_hours:avg']):
            row_for(job_type)['avg_close_hours'] = round(hours or 0.0, 2)
        result = sorted(
            rows.values(),
            key=lambda row: -(row['resolved'] + row['in_progress'] + row['unassigned']),
        )
        return result

    def _dashboard_by_month(self, domain, filters):
        """Tickets created each month, split by whether they are resolved now.
        Every month of the period is listed, even empty ones."""
        counts = {}
        for bucket, is_closed in (('resolved', True), ('unresolved', False)):
            for month, number in self._read_group(
                domain + [('stage_id.is_closed', '=', is_closed)], ['create_date:month'], ['__count'],
            ):
                if not month:
                    continue
                key = month.strftime('%Y-%m')
                counts.setdefault(key, {'resolved': 0, 'unresolved': 0})
                counts[key][bucket] += number

        today = fields.Date.context_today(self)
        start = fields.Date.to_date(filters.get('date_from')) or (
            date.fromisoformat(min(counts) + '-01') if counts else today
        )
        end = fields.Date.to_date(filters.get('date_to')) or today
        months = []
        cursor = start.replace(day=1)
        while cursor <= end and len(months) < 36:
            key = cursor.strftime('%Y-%m')
            values = counts.get(key, {'resolved': 0, 'unresolved': 0})
            next_month = cursor + relativedelta(months=1)
            months.append({
                'key': key,
                'label': cursor.strftime('%b %Y') if start.year != end.year else cursor.strftime('%b'),
                'domain': [
                    ('create_date', '>=', self._dashboard_utc(cursor)),
                    ('create_date', '<', self._dashboard_utc(next_month)),
                ],
                **values,
            })
            cursor += relativedelta(months=1)
        return months

    def _dashboard_by_engineer(self, domain):
        resolved = [('stage_id.is_closed', '=', True)]
        rows = [
            {'id': user.id, 'name': user.name, 'count': number, 'domain': [('user_ids', 'in', [user.id])]}
            for user, number in self._read_group(domain + resolved, ['user_ids'], ['__count'])
            if user
        ]
        rows.sort(key=lambda row: (-row['count'], row['name']))
        return rows[:ENGINEER_LIMIT]

    def _dashboard_options(self):
        group = self.env.ref('nifty_helpdesk.group_helpdesk_user')
        users = self.env['res.users'].search([('groups_id', 'in', group.ids), ('share', '=', False)], order='name')
        return {
            'teams': [{'id': team.id, 'name': team.name} for team in self.env['helpdesk.team'].search([])],
            'engineers': [{'id': user.id, 'name': user.name} for user in users],
            'job_types': [{'id': jt.id, 'name': jt.name} for jt in self.env['helpdesk.job.type'].search([])],
            'priorities': [{'id': key, 'name': label} for key, label in self._fields['priority'].selection],
        }
