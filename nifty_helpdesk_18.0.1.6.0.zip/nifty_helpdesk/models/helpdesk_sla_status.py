from odoo import api, fields, models

STATUS_COLORS = {'ongoing': 0, 'reached': 10, 'failed': 1}


class HelpdeskSlaStatus(models.Model):
    _name = 'helpdesk.sla.status'
    _description = 'Helpdesk Ticket SLA Status'
    _order = 'deadline, id'

    ticket_id = fields.Many2one('helpdesk.ticket', required=True, ondelete='cascade', index=True)
    sla_id = fields.Many2one('helpdesk.sla', string='SLA Policy', required=True, ondelete='cascade', index=True)
    deadline = fields.Datetime(index=True)
    reached_datetime = fields.Datetime(string='Reached On')
    paused_since = fields.Datetime(help='Set while the ticket sits in an excluded stage.')
    status = fields.Selection(
        [('ongoing', 'In Progress'), ('reached', 'Met'), ('failed', 'Failed')],
        required=True, default='ongoing', index=True,
    )
    color = fields.Integer(compute='_compute_color')
    hours_to_reach = fields.Float(
        string='Working Hours to Reach', compute='_compute_hours_to_reach', store=True, aggregator='avg',
    )

    _sql_constraints = [
        ('ticket_sla_uniq', 'unique (ticket_id, sla_id)', 'A ticket can only have one status per SLA policy.'),
    ]

    @api.depends('sla_id.name')
    def _compute_display_name(self):
        for status in self:
            status.display_name = status.sla_id.name

    @api.depends('status')
    def _compute_color(self):
        for status in self:
            status.color = STATUS_COLORS.get(status.status, 0)

    @api.depends('reached_datetime')
    def _compute_hours_to_reach(self):
        for status in self:
            start = status.ticket_id.create_date
            end = status.reached_datetime
            if start and end and end > start:
                status.hours_to_reach = status.sla_id.resource_calendar_id.get_work_hours_count(
                    start, end, compute_leaves=True,
                )
            else:
                status.hours_to_reach = 0.0

    def _resume(self, now):
        """Push the deadline back by the working hours spent in an excluded stage."""
        for status in self.filtered('paused_since'):
            calendar = status.sla_id.resource_calendar_id
            values = {'paused_since': False}
            paused_hours = calendar.get_work_hours_count(status.paused_since, now, compute_leaves=True)
            if paused_hours and status.deadline:
                values['deadline'] = calendar.plan_hours(paused_hours, status.deadline, compute_leaves=True)
            status.write(values)

    def _on_ticket_stage(self, stage, now):
        self.ensure_one()
        sla = self.sla_id
        if self.paused_since and (stage not in sla.exclude_stage_ids or sla._is_reached_by(stage)):
            self._resume(now)
        if sla._is_reached_by(stage):
            failed = self.status == 'failed' or bool(self.deadline and now > self.deadline)
            self.write({'reached_datetime': now, 'status': 'failed' if failed else 'reached'})
        elif stage in sla.exclude_stage_ids and not self.paused_since:
            self.paused_since = now

    @api.model
    def _cron_mark_failed(self):
        self.search([
            ('status', '=', 'ongoing'),
            ('paused_since', '=', False),
            ('deadline', '<', fields.Datetime.now()),
        ]).status = 'failed'
