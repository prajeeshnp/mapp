import ast
from datetime import timedelta

from markupsafe import Markup

from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

TODAY_LIST_LIMIT = 8
OVERVIEW_STATUS_DAYS = 30
OVERVIEW_TREND_DAYS = 7


class HelpdeskTeam(models.Model):
    _name = 'helpdesk.team'
    _description = 'Helpdesk Team'
    _inherit = ['mail.alias.mixin', 'mail.thread', 'rating.parent.mixin']
    _order = 'name, id'
    _rating_satisfaction_days = 30

    def _default_stage_ids(self):
        return self.env['helpdesk.stage'].search([])

    def _domain_member_ids(self):
        group = self.env.ref('nifty_helpdesk.group_helpdesk_user')
        return [('groups_id', 'in', group.ids), ('share', '=', False)]

    name = fields.Char(required=True, translate=True, tracking=True)
    active = fields.Boolean(default=True)
    visibility = fields.Selection(
        [
            ('invited', 'Invited users only'),
            ('internal', 'All internal users'),
            ('portal', 'Internal users and customers'),
        ],
        required=True,
        default='invited',
        tracking=True,
        help='Invited users only: team members and followers of a ticket can see it.\n'
             'All internal users: every Helpdesk User can see the team and its tickets.\n'
             'Internal users and customers: also gives customers portal access to '
             'tickets they raised or follow.',
    )
    member_ids = fields.Many2many(
        'res.users',
        'helpdesk_team_user_rel',
        'team_id',
        'user_id',
        string='Members',
        domain=_domain_member_ids,
        help='Leave empty to let any Helpdesk User be assigned.',
    )
    assignment_method = fields.Selection(
        [
            ('manual', 'Manual'),
            ('round_robin', 'Round-robin'),
            ('balanced', 'Balanced'),
        ],
        required=True,
        default='manual',
        tracking=True,
        help='Manual: tickets stay unassigned.\n'
             'Round-robin: members take turns.\n'
             'Balanced: the member with the fewest open tickets is picked.',
    )
    stage_ids = fields.Many2many(
        'helpdesk.stage',
        'helpdesk_team_stage_rel',
        'team_id',
        'stage_id',
        string='Stages',
        default=_default_stage_ids,
    )
    last_assigned_user_id = fields.Many2one(
        'res.users',
        string='Last Assigned User',
        readonly=True,
        copy=False,
        ondelete='set null',
    )
    ticket_ids = fields.One2many('helpdesk.ticket', 'team_id', string='Tickets')

    # Closing
    closing_stage_id = fields.Many2one(
        'helpdesk.stage',
        string='Closing Stage',
        compute='_compute_closing_stage_id',
        store=True,
        readonly=False,
        domain="[('id', 'in', stage_ids), ('is_closed', '=', True)]",
        help='Stage used when tickets are closed automatically or by the customer.',
    )
    auto_close = fields.Boolean(string='Close Inactive Tickets')
    auto_close_days = fields.Integer(string='Inactive Days', default=7)
    auto_close_stage_ids = fields.Many2many(
        'helpdesk.stage',
        'helpdesk_team_auto_close_stage_rel',
        'team_id',
        'stage_id',
        string='Watched Stages',
        domain="[('id', 'in', stage_ids), ('is_closed', '=', False)]",
        help='Only tickets in these stages are closed. Leave empty to watch every open stage.',
    )
    allow_customer_close = fields.Boolean(
        string='Customers Can Close Tickets',
        help='Shows a Close button on the customer portal.',
    )

    # Performance
    use_rating = fields.Boolean(string='Customer Ratings')
    rating_public = fields.Boolean(
        string='Publish Ratings',
        help='Shows the last 30 days of rating statistics on a public page. '
             'Requires customer access to the team.',
    )
    use_sla = fields.Boolean(string='Use SLA Policies', default=True)
    sla_ids = fields.One2many('helpdesk.sla', 'team_id', string='SLA Policies')
    resource_calendar_id = fields.Many2one(
        'resource.calendar',
        string='Working Hours',
        default=lambda self: self.env.company.resource_calendar_id,
        help='Used to count working hours in reports.',
    )

    # Overview counts
    open_ticket_count = fields.Integer(compute='_compute_ticket_counts', string='Open')
    urgent_ticket_count = fields.Integer(compute='_compute_ticket_counts', string='Urgent')
    unassigned_ticket_count = fields.Integer(compute='_compute_ticket_counts', string='Unassigned')
    sla_failed_ticket_count = fields.Integer(compute='_compute_ticket_counts', string='SLA Failed')
    today_ticket_count = fields.Integer(compute='_compute_ticket_counts', string='Scheduled Today')
    overview_stats = fields.Json(compute='_compute_overview_stats', string='Overview Charts')
    today_ticket_summary = fields.Html(
        compute='_compute_today_ticket_summary', sanitize=False, string="Today's Schedule",
    )

    @api.constrains('stage_ids')
    def _check_stage_ids(self):
        for team in self:
            if not team.stage_ids:
                raise ValidationError(_('Team "%s" needs at least one stage.', team.name))

    @api.constrains('closing_stage_id', 'stage_ids')
    def _check_closing_stage_id(self):
        for team in self:
            stage = team.closing_stage_id
            if stage and (stage not in team.stage_ids or not stage.is_closed):
                raise ValidationError(_(
                    'The closing stage of team "%s" must be one of its closing stages.', team.name,
                ))

    @api.constrains('auto_close', 'auto_close_days', 'closing_stage_id')
    def _check_auto_close(self):
        for team in self.filtered('auto_close'):
            if team.auto_close_days < 1:
                raise ValidationError(_('Inactive days must be at least 1.'))
            if not team.closing_stage_id:
                raise ValidationError(_('Set a closing stage before closing inactive tickets.'))

    @api.constrains('rating_public', 'visibility', 'use_rating')
    def _check_rating_public(self):
        for team in self.filtered('rating_public'):
            if team.visibility != 'portal' or not team.use_rating:
                raise ValidationError(_(
                    'Ratings can only be published for teams with customer ratings '
                    'and customer access.',
                ))

    @api.depends('stage_ids', 'stage_ids.is_closed')
    def _compute_closing_stage_id(self):
        for team in self:
            if team.closing_stage_id not in team.stage_ids.filtered('is_closed'):
                team.closing_stage_id = team.stage_ids.filtered('is_closed')[:1]

    def _compute_ticket_counts(self):
        Ticket = self.env['helpdesk.ticket']
        base_domain = [('team_id', 'in', self.ids), ('stage_id.is_closed', '=', False)]
        counters = {
            'open_ticket_count': [],
            'urgent_ticket_count': [('priority', '=', '3')],
            'unassigned_ticket_count': [('user_ids', '=', False)],
            'sla_failed_ticket_count': [('sla_failed', '=', True)],
            'today_ticket_count': Ticket._scheduled_today_domain(),
        }
        for field_name, extra_domain in counters.items():
            counts = dict(Ticket._read_group(base_domain + extra_domain, ['team_id'], ['__count']))
            for team in self:
                team[field_name] = counts.get(team, 0)

    def _overview_segment_domain(self, kind, key):
        """Ticket domain behind one segment of an Overview chart."""
        now = fields.Datetime.now()
        if kind == 'status':
            since = fields.Datetime.to_string(now - timedelta(days=OVERVIEW_STATUS_DAYS))
            return [('create_date', '>=', since)] + {
                'resolved': [('stage_id.is_closed', '=', True)],
                'in_progress': [('stage_id.is_closed', '=', False), ('user_ids', '!=', False)],
                'unassigned': [('stage_id.is_closed', '=', False), ('user_ids', '=', False)],
            }[key]
        if kind == 'priority':
            return [('stage_id.is_closed', '=', False), ('priority', '=', key)]
        if kind in ('created', 'resolved'):
            day = fields.Date.to_date(key)
            Ticket = self.env['helpdesk.ticket']
            start, end = Ticket._dashboard_utc(day), Ticket._dashboard_utc(day + timedelta(days=1))
            field_name = 'create_date' if kind == 'created' else 'close_date'
            return [(field_name, '>=', start), (field_name, '<', end)]
        raise ValueError(kind)

    def _compute_overview_stats(self):
        Ticket = self.env['helpdesk.ticket']
        base = [('team_id', 'in', self.ids)]
        status_defs = [
            ('resolved', _('Resolved')),
            ('in_progress', _('In progress')),
            ('unassigned', _('Unassigned')),
        ]
        status = {}
        for key, _label in status_defs:
            domain = base + self._overview_segment_domain('status', key)
            status[key] = dict(Ticket._read_group(domain, ['team_id'], ['__count']))
        open_domain = base + [('stage_id.is_closed', '=', False)]
        priority = {}
        for team, prio, number in Ticket._read_group(open_domain, ['team_id', 'priority'], ['__count']):
            priority.setdefault(team.id, {})[prio] = number

        # Last 7 days in the user's time zone, oldest first.
        today = fields.Date.context_today(self)
        days = [today - timedelta(days=offset) for offset in range(OVERVIEW_TREND_DAYS - 1, -1, -1)]
        start = Ticket._dashboard_utc(days[0])
        created, resolved = {}, {}
        for target, field_name in ((created, 'create_date'), (resolved, 'close_date')):
            for team, day, number in Ticket._read_group(
                base + [(field_name, '>=', start)], ['team_id', f'{field_name}:day'], ['__count'],
            ):
                target[(team.id, day.date() if hasattr(day, 'date') else day)] = number

        for team in self:
            team.overview_stats = {
                'status_days': OVERVIEW_STATUS_DAYS,
                'status': [
                    {'key': key, 'label': label, 'count': status[key].get(team, 0)}
                    for key, label in status_defs
                ],
                'priority': [
                    {'key': key, 'label': label, 'count': priority.get(team.id, {}).get(key, 0)}
                    for key, label in Ticket._fields['priority'].selection
                ],
                'trend': [
                    {
                        'key': day.isoformat(),
                        'label': day.strftime('%a'),
                        'created': created.get((team.id, day), 0),
                        'resolved': resolved.get((team.id, day), 0),
                    }
                    for day in days
                ],
            }

    def action_view_overview_segment(self, kind, key):
        self.ensure_one()
        action = self._action_view_tickets()
        action['domain'] = action['domain'] + self._overview_segment_domain(kind, key)
        # A list shows every match; the kanban would hide tickets in folded
        # (closed) stages, e.g. ones resolved the same day.
        action['views'] = [(False, 'list'), (False, 'kanban'), (False, 'form')]
        action['view_mode'] = 'list,kanban,form'
        return action

    def _compute_today_ticket_summary(self):
        Ticket = self.env['helpdesk.ticket']
        domain = [('team_id', 'in', self.ids), ('stage_id.is_closed', '=', False)]
        tickets = Ticket.search(domain + Ticket._scheduled_today_domain(), order='scheduled_date, id')
        by_team = {}
        for ticket in tickets:
            by_team.setdefault(ticket.team_id.id, Ticket)
            by_team[ticket.team_id.id] |= ticket
        for team in self:
            team_tickets = by_team.get(team.id, Ticket)
            if not team_tickets:
                team.today_ticket_summary = False
                continue
            rows = []
            for ticket in team_tickets[:TODAY_LIST_LIMIT]:
                local = fields.Datetime.context_timestamp(self, ticket.scheduled_date)
                engineers = ', '.join(ticket.user_ids.mapped('name')) or _('Unassigned')
                rows.append(Markup(
                    '<li class="d-flex gap-2 py-1 border-bottom">'
                    '<span class="fw-bold text-nowrap">%s</span>'
                    '<span class="flex-grow-1 text-truncate">%s</span>'
                    '<span class="text-muted text-truncate">%s</span>'
                    '</li>'
                ) % (local.strftime('%H:%M'), ticket.display_name, engineers))
            more = len(team_tickets) - TODAY_LIST_LIMIT
            if more > 0:
                rows.append(Markup('<li class="text-muted pt-1">%s</li>') % _('and %s more', more))
            team.today_ticket_summary = Markup('<ul class="list-unstyled mb-0 small">%s</ul>') % Markup('').join(rows)

    def write(self, vals):
        leaving_portal = vals.get('visibility') and vals['visibility'] != 'portal'
        if leaving_portal:
            # Public ratings need customer access, so they switch off with it.
            vals = dict(vals, rating_public=False)
        result = super().write(vals)
        if leaving_portal:
            self._remove_portal_followers()
        return result

    def _remove_portal_followers(self):
        """Customers lose access when a team stops being visible to them, so they
        should not keep receiving its notifications either."""
        for team in self:
            tickets = team.with_context(active_test=False).ticket_ids
            records = [team] + list(tickets)
            for record in records:
                portal_partners = record.message_partner_ids.filtered(
                    lambda partner: partner.user_ids and partner.partner_share
                )
                if portal_partners:
                    record.message_unsubscribe(partner_ids=portal_partners.ids)

    def _get_calendar(self):
        self.ensure_one()
        return self.resource_calendar_id or self.env.company.resource_calendar_id

    def _alias_get_creation_values(self):
        values = super()._alias_get_creation_values()
        values['alias_model_id'] = self.env['ir.model']._get_id('helpdesk.ticket')
        if self.id:
            defaults = ast.literal_eval(self.alias_defaults or '{}')
            defaults['team_id'] = self.id
            values['alias_defaults'] = defaults
        return values

    # ------------------------------------------------------------
    # Assignment
    # ------------------------------------------------------------

    def _get_assignable_users(self):
        """Team members, or every internal Helpdesk User when the team has none."""
        self.ensure_one()
        team = self.sudo()
        if team.member_ids:
            return team.member_ids.filtered('active')
        group = self.env.ref('nifty_helpdesk.group_helpdesk_user')
        return self.env['res.users'].sudo().search([
            ('groups_id', 'in', group.ids),
            ('share', '=', False),
        ])

    def _get_next_assignee(self):
        """Return the user who should get this team's next ticket, or an empty
        recordset when the team assigns manually or nobody can be assigned."""
        self.ensure_one()
        team = self.sudo()
        if team.assignment_method == 'manual':
            return self.env['res.users']
        users = team._get_assignable_users().sorted('id')
        if not users:
            return self.env['res.users']
        if team.assignment_method == 'round_robin':
            return team._get_round_robin_assignee(users)
        return team._get_balanced_assignee(users)

    def _get_round_robin_assignee(self, users):
        # Writing the pointer makes concurrent creates conflict on the team row,
        # so the transaction is retried instead of assigning the same user twice.
        last_id = self.last_assigned_user_id.id or 0
        assignee = users.filtered(lambda user: user.id > last_id)[:1] or users[:1]
        self.last_assigned_user_id = assignee
        return assignee

    def _get_balanced_assignee(self, users):
        # A ticket shared by several engineers counts once for each of them.
        open_counts = dict(self.env['helpdesk.ticket'].sudo()._read_group(
            [
                ('team_id', '=', self.id),
                ('user_ids', 'in', users.ids),
                ('stage_id.is_closed', '=', False),
            ],
            ['user_ids'],
            ['__count'],
        ))
        return min(users, key=lambda user: (open_counts.get(user, 0), user.id))

    # ------------------------------------------------------------
    # Scheduled jobs
    # ------------------------------------------------------------

    @api.model
    def _cron_close_inactive_tickets(self):
        now = fields.Datetime.now()
        Ticket = self.env['helpdesk.ticket']
        for team in self.search([('auto_close', '=', True), ('closing_stage_id', '!=', False)]):
            domain = [
                ('team_id', '=', team.id),
                ('stage_id.is_closed', '=', False),
                ('last_activity_date', '<', now - timedelta(days=team.auto_close_days)),
            ]
            if team.auto_close_stage_ids:
                domain.append(('stage_id', 'in', team.auto_close_stage_ids.ids))
            tickets = Ticket.search(domain)
            if not tickets:
                continue
            tickets.write({'stage_id': team.closing_stage_id.id})
            for ticket in tickets:
                ticket.message_post(
                    body=_('Closed automatically after %s days without activity.', team.auto_close_days),
                    subtype_xmlid='mail.mt_note',
                )

    # ------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------

    def _action_view_tickets(self, **search_defaults):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id('nifty_helpdesk.action_helpdesk_ticket')
        action['display_name'] = self.name
        action['domain'] = [('team_id', '=', self.id)]
        action['context'] = {'default_team_id': self.id, **search_defaults}
        return action

    def action_view_tickets(self):
        return self._action_view_tickets()

    def action_view_open_tickets(self):
        return self._action_view_tickets(search_default_open=1)

    def action_view_urgent_tickets(self):
        return self._action_view_tickets(search_default_open=1, search_default_urgent=1)

    def action_view_unassigned_tickets(self):
        return self._action_view_tickets(search_default_open=1, search_default_unassigned=1)

    def action_view_sla_failed_tickets(self):
        return self._action_view_tickets(search_default_open=1, search_default_sla_failed=1)

    def action_view_today_tickets(self):
        return self._action_view_tickets(search_default_open=1, search_default_scheduled_today=1)

    def action_view_ratings(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id('nifty_helpdesk.action_helpdesk_rating')
        action['domain'] = [('parent_res_model', '=', self._name), ('parent_res_id', '=', self.id)]
        return action

    def action_open_public_ratings(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_url',
            'url': f'/helpdesk/rating/{self.id}',
            'target': 'new',
        }
