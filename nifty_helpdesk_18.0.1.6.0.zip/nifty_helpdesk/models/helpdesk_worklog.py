from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

MAX_SESSION_HOURS = 24


class HelpdeskTicketWorklog(models.Model):
    _name = 'helpdesk.ticket.worklog'
    _description = 'Helpdesk Work Session'
    _order = 'start desc, id desc'

    ticket_id = fields.Many2one('helpdesk.ticket', string='Ticket', required=True, ondelete='cascade', index=True)
    team_id = fields.Many2one(related='ticket_id.team_id', store=True, index=True)
    user_id = fields.Many2one(
        'res.users', string='Engineer', required=True, index=True,
        default=lambda self: self.env.user,
        domain=lambda self: [('groups_id', 'in', self.env.ref('nifty_helpdesk.group_helpdesk_user').ids),
                             ('share', '=', False)],
    )
    start = fields.Datetime(required=True, default=fields.Datetime.now)
    end = fields.Datetime(help='Leave empty and enter a duration instead if you only know how long it took.')
    duration = fields.Float(
        string='Hours', compute='_compute_duration', store=True, readonly=False, aggregator='sum',
        help='Worked time. Calculated from start and end when both are set.',
    )
    description = fields.Char(string='Work Done')

    @api.depends('start', 'end')
    def _compute_duration(self):
        for log in self:
            if log.start and log.end:
                log.duration = round((log.end - log.start).total_seconds() / 3600.0, 4)

    @api.constrains('start', 'end', 'duration')
    def _check_times(self):
        for log in self:
            if log.end and log.end <= log.start:
                raise ValidationError(_('A work session must end after it starts.'))
            if log.duration <= 0:
                raise ValidationError(_('Enter an end time or a duration greater than zero.'))
            if log.duration > MAX_SESSION_HOURS:
                raise ValidationError(_('A single work session cannot be longer than %s hours.', MAX_SESSION_HOURS))

    @api.depends('ticket_id', 'user_id', 'duration')
    def _compute_display_name(self):
        for log in self:
            hours, minutes = divmod(round(log.duration * 60), 60)
            log.display_name = f'{log.ticket_id.ref or ""} · {log.user_id.name or ""} · {hours}:{minutes:02d}'
