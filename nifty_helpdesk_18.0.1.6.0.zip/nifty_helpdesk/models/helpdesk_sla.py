from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

from .helpdesk_ticket import PRIORITIES


class HelpdeskSla(models.Model):
    _name = 'helpdesk.sla'
    _description = 'Helpdesk SLA Policy'
    _order = 'team_id, priority, id'

    name = fields.Char(required=True, translate=True)
    active = fields.Boolean(default=True)
    description = fields.Text()
    team_id = fields.Many2one('helpdesk.team', string='Team', required=True, ondelete='cascade', index=True)
    priority = fields.Selection(
        PRIORITIES, required=True, default='0',
        help='The policy applies to tickets with exactly this priority.',
    )
    tag_ids = fields.Many2many(
        'helpdesk.tag', 'helpdesk_sla_tag_rel', 'sla_id', 'tag_id', string='Tags',
        help='If set, the ticket needs at least one of these tags.',
    )
    partner_ids = fields.Many2many(
        'res.partner', 'helpdesk_sla_partner_rel', 'sla_id', 'partner_id', string='Customers',
        help="If set, the ticket's customer or its company must be one of these.",
    )
    team_stage_ids = fields.Many2many(related='team_id.stage_ids', string='Team Stages')
    stage_id = fields.Many2one(
        'helpdesk.stage', string='Target Stage', required=True,
        domain="[('id', 'in', team_stage_ids)]",
        help='The SLA is met when the ticket reaches this stage or any later one.',
    )
    exclude_stage_ids = fields.Many2many(
        'helpdesk.stage', 'helpdesk_sla_exclude_stage_rel', 'sla_id', 'stage_id',
        string='Excluded Stages',
        domain="[('id', 'in', team_stage_ids)]",
        help='Time spent in these stages does not count towards the deadline.',
    )
    time = fields.Float(string='Time Limit (Hours)', required=True, help='Working hours to reach the target stage.')
    resource_calendar_id = fields.Many2one(
        'resource.calendar', string='Working Hours', required=True,
        default=lambda self: self.env.company.resource_calendar_id,
    )

    @api.constrains('time')
    def _check_time(self):
        if any(sla.time <= 0 for sla in self):
            raise ValidationError(_('The time limit must be greater than zero.'))

    @api.constrains('stage_id', 'exclude_stage_ids', 'team_id')
    def _check_stages(self):
        for sla in self:
            if sla.stage_id not in sla.team_id.stage_ids:
                raise ValidationError(_('The target stage of "%s" must belong to its team.', sla.name))
            if sla.stage_id in sla.exclude_stage_ids:
                raise ValidationError(_('The target stage of "%s" cannot also be excluded.', sla.name))

    def _matches(self, ticket):
        self.ensure_one()
        if ticket.team_id != self.team_id or ticket.priority != self.priority:
            return False
        if self.tag_ids and not (self.tag_ids & ticket.tag_ids):
            return False
        if self.partner_ids:
            partner = ticket.partner_id
            if not partner or not ((partner | partner.commercial_partner_id) & self.partner_ids):
                return False
        return True

    def _compute_deadline(self, start):
        self.ensure_one()
        return self.resource_calendar_id.plan_hours(self.time, start, compute_leaves=True)

    def _is_reached_by(self, stage):
        self.ensure_one()
        return stage.sequence >= self.stage_id.sequence

    def _prepare_status_values(self, ticket, now):
        self.ensure_one()
        deadline = self._compute_deadline(ticket.create_date or now)
        values = {'ticket_id': ticket.id, 'sla_id': self.id, 'deadline': deadline, 'status': 'ongoing'}
        if self._is_reached_by(ticket.stage_id):
            values.update(reached_datetime=now, status='failed' if deadline and now > deadline else 'reached')
        elif ticket.stage_id in self.exclude_stage_ids:
            values['paused_since'] = now
        elif deadline and now > deadline:
            values['status'] = 'failed'
        return values
